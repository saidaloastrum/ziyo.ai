// Заранее готовит уроки, мини-уроки и тесты по всем главам, чтобы ученики не ждали генерации.
// Запуск: npm run pregenerate  (нужен ANTHROPIC_API_KEY). Только один язык: LANGS=uz npm run pregenerate. Готовый материал можно просмотреть в таблице content (SQLite).
require('../lib/env');
const content = require('../lib/content');
const { CH } = require('../lib/catalog');
(async () => {
  let ok = 0, bad = 0;
  const langs = (process.env.LANGS || 'ru,uz').split(',');
  for (const lang of langs) for (const c of Object.values(CH)) {
    const jobs = [[`${lang} урок ${c.id}`, () => content.getLesson(c.id, lang)]];
    for (const t of c.topics) {
      jobs.push([`${lang} мини-урок ${t.id}`, () => content.getMini(t.id, lang)]);
      jobs.push([`${lang} тесты ${t.id}`, () => content.getQuestions(t.id, lang)]);
    }
    for (const [name, fn] of jobs) {
      try { await fn(); ok++; console.log('ok  ', name); }
      catch (e) { bad++; console.log('FAIL', name, e.message.slice(0, 120)); }
    }
  }
  console.log(`Готово: ${ok} успешно, ${bad} с ошибками (повторный запуск доделает недостающее).`);
})();
