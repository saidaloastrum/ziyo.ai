// Ручная резервная копия: npm run backup (можно запускать при работающем сервере).
// Копии лежат в data/backups (или BACKUP_DIR), хранятся последние BACKUP_KEEP штук.
// Не забывайте уносить копии и папку data/receipts с сервера (например, scp раз в неделю).
require('../lib/env');
require('../lib/backup').backupNow()
  .then(f => { console.log('Готово:', f); process.exit(0); })
  .catch(e => { console.error('Ошибка:', e.message); process.exit(1); });
