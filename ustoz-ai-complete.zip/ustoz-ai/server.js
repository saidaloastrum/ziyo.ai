require('./lib/env');
const express = require('express');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const { OAuth2Client } = require('google-auth-library');
const db = require('./lib/db');
const { SUBJECTS, DIRECTIONS, FREE_CHAPTERS, CH, TOPIC, PLANS, chTitle, topicName, subjName, localized, chatLimits } = require('./lib/catalog');
const content = require('./lib/content');
const ai = require('./lib/ai');
const gamify = require('./lib/gamify');
const billing = require('./lib/billing');
const payme = require('./lib/payme');
const tg = require('./lib/telegram');
const backup = require('./lib/backup');
const { PERSONAS, personaOf } = require('./lib/personas');
const { progressFor, isActive, decayed, INTERVALS, DAY } = require('./lib/progress');

const PORT = +process.env.PORT || 3000;
const HOST = process.env.HOST || '127.0.0.1'; // наружу сайт отдаёт nginx; прямой доступ к порту позволил бы подделывать IP
const DEV = process.env.DEV_MODE === '1';
const PROD = process.env.NODE_ENV === 'production';
if (DEV && PROD) {
  console.error('Ошибка: DEV_MODE=1 нельзя включать при NODE_ENV=production — это вход без пароля и подписка без оплаты. Поставьте DEV_MODE=0.');
  process.exit(1);
}
const GID = process.env.GOOGLE_CLIENT_ID || '';
const gclient = GID ? new OAuth2Client(GID) : null;
const TEST_LEN = 20, PASS_RATIO = 0.75, MAX_HELP = 6;
const RECEIPTS = path.resolve(process.env.RECEIPTS_DIR || path.join(db.dataDir, 'receipts'));
content.migrateIds();

const app = express();
app.disable('x-powered-by');
app.set('trust proxy', 1);
app.use(express.json({ limit: '100kb' }));
app.use((req, res, next) => {
  res.set({
    'X-Content-Type-Options': 'nosniff', 'Referrer-Policy': 'same-origin', 'X-Frame-Options': 'DENY',
    'Content-Security-Policy': "frame-ancestors 'none'; base-uri 'self'; object-src 'none'; form-action 'self'",
    'Permissions-Policy': 'geolocation=(), microphone=()'
  });
  next();
});

/* ---------- язык и сообщения ---------- */
const M = {
  ru: { login: 'Требуется вход', gOff: 'Вход через Google не настроен на сервере', many: 'Слишком много попыток', emailNV: 'Почта Google не подтверждена',
    gFail: 'Не удалось подтвердить вход через Google', nameEmail: 'Введите имя и почту', badDir: 'Неизвестное направление', noChapter: 'Глава не найдена',
    needSub: 'Эта глава доступна по подписке', tooTests: 'Слишком много тестов за час. Сделайте паузу.', noTest: 'Тест не найден или уже завершён',
    badChoice: 'Неверный вариант', noCode: 'Код не найден', tooReq: 'Слишком много запросов', badPlan: 'Неизвестный тариф',
    noMaterial: 'Материалы этой главы ещё не подготовлены. Попробуйте позже.', genFail: 'Не удалось подготовить материал. Попробуйте ещё раз через минуту.',
    notFound: 'Не найдено', server: 'Ошибка сервера', manual: 'Онлайн-оплата ещё не подключена. Напишите нам, и мы откроем доступ после перевода.', badLang: 'Неизвестный язык',
    helpOff: 'Подсказки сейчас недоступны.', helpMax: 'Подсказки по этому вопросу закончились. Посмотрите разбор.', noReview: 'Сейчас нечего повторять.',
    nickBad: 'Ник: 3–16 символов, буквы, цифры и _', nickTaken: 'Этот ник уже занят', badStyle: 'Неизвестный стиль',
    resync: 'Тест продолжился с другого места (например, после сбоя связи). Показываем актуальный вопрос.', chatOff: 'Наставник сейчас недоступен. Попробуйте позже.',
    chatEmpty: 'Напишите вопрос.', chatMaxFree: 'На сегодня вопросы закончились. Завтра лимит обновится, а с подпиской вопросов больше.',
    chatMaxPaid: 'На сегодня вопросы закончились. Завтра лимит обновится.', payOff: 'Оплата пока не настроена. Напишите нам, и мы откроем доступ вручную.',
    receiptBad: 'Загрузите скриншот или фото чека: JPG, PNG или WebP.', receiptBig: 'Файл слишком большой. Загрузите изображение до 6 МБ.',
    orderState: 'Этот заказ уже обработан.', badPersona: 'Неизвестный наставник', deleteConfirm: 'Подтвердите удаление аккаунта.',
    noQuestions: 'Вопросы этой главы сейчас на проверке. Загляните чуть позже.' },
  uz: { login: 'Kirish talab qilinadi', gOff: 'Google orqali kirish serverda sozlanmagan', many: "Juda ko'p urinish", emailNV: 'Google pochtasi tasdiqlanmagan',
    gFail: "Google orqali kirishni tasdiqlab bo'lmadi", nameEmail: 'Ism va pochtani kiriting', badDir: "Noma'lum yo'nalish", noChapter: 'Bob topilmadi',
    needSub: 'Bu bob obuna orqali ochiladi', tooTests: "Bir soatda juda ko'p test. Biroz dam oling.", noTest: 'Test topilmadi yoki allaqachon tugagan',
    badChoice: "Noto'g'ri variant", noCode: 'Kod topilmadi', tooReq: "Juda ko'p so'rov", badPlan: "Noma'lum tarif",
    noMaterial: "Bu bobning materiallari hali tayyor emas. Keyinroq urinib ko'ring.", genFail: "Materialni tayyorlab bo'lmadi. Bir daqiqadan so'ng qayta urinib ko'ring.",
    notFound: 'Topilmadi', server: 'Server xatosi', manual: "Onlayn to'lov hali ulanmagan. Bizga yozing, o'tkazmadan keyin kirishni ochamiz.", badLang: "Noma'lum til",
    helpOff: 'Maslahatlar hozir mavjud emas.', helpMax: "Bu savol bo'yicha maslahatlar tugadi. Tahlilga qarang.", noReview: "Hozir takrorlaydigan narsa yo'q.",
    nickBad: 'Laqab: 3–16 belgi, harflar, raqamlar va _', nickTaken: 'Bu laqab band', badStyle: "Noma'lum uslub",
    resync: "Test boshqa joydan davom etdi (masalan, aloqa uzilgandan keyin). Joriy savolni ko'rsatamiz.", chatOff: "Ustoz hozir mavjud emas. Keyinroq urinib ko'ring.",
    chatEmpty: 'Savolingizni yozing.', chatMaxFree: "Bugungi savollar tugadi. Ertaga limit yangilanadi, obuna bilan esa savollar ko'proq.",
    chatMaxPaid: 'Bugungi savollar tugadi. Ertaga limit yangilanadi.', payOff: "To'lov hali sozlanmagan. Bizga yozing, kirishni qo'lda ochamiz.",
    receiptBad: 'Chek skrinshoti yoki rasmini yuklang: JPG, PNG yoki WebP.', receiptBig: 'Fayl juda katta. 6 MB gacha rasm yuklang.',
    orderState: "Bu buyurtma allaqachon ko'rib chiqilgan.", badPersona: "Noma'lum ustoz", deleteConfirm: "Akkauntni o'chirishni tasdiqlang.",
    noQuestions: 'Bu bob savollari hozir tekshiruvda. Birozdan keyin kiring.' }
};
const langOf = req => { const h = String(req.headers['x-lang'] || ''); return (h === 'uz' || h === 'ru') ? h : ((req.user && req.user.lang) || 'ru'); };
const m = (req, k) => M[langOf(req)][k];
const fail = (req, res, status, key) => res.status(status).json({ error: m(req, key) });

/* ---------- утилиты ---------- */
const own = (o, k) => (typeof k === 'string' && Object.prototype.hasOwnProperty.call(o, k)) ? o[k] : undefined; // защищает от ключей вида __proto__
const shuffle = a => { a = a.slice(); for (let i = a.length - 1; i > 0; i--) { const j = crypto.randomInt(i + 1); [a[i], a[j]] = [a[j], a[i]]; } return a; };
const sha = s => crypto.createHash('sha256').update(s).digest('hex');
const tashDay = ms => new Date(ms + 5 * 3600e3).toISOString().slice(0, 10);
const dayStart = (ms = Date.now()) => Date.parse(tashDay(ms) + 'T00:00:00Z') - 5 * 3600e3;
const hits = new Map();
function limited(key, max, win) {
  const now = Date.now(), a = (hits.get(key) || []).filter(t => now - t < win);
  a.push(now); hits.set(key, a); return a.length > max;
}
setInterval(() => { const now = Date.now(); for (const [k, a] of hits) if (!a.some(t => now - t < 3600e3)) hits.delete(k); }, 600e3).unref();
function cookies(req) {
  const o = {};
  (req.headers.cookie || '').split(';').forEach(p => {
    const i = p.indexOf('=');
    if (i > 0) { try { o[p.slice(0, i).trim()] = decodeURIComponent(p.slice(i + 1).trim()); } catch (e) { /* битая cookie: пропускаем */ } }
  });
  return o;
}
function newParentCode() {
  const A = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  for (;;) {
    let c = ''; const b = crypto.randomBytes(8);
    for (let i = 0; i < 8; i++) c += A[b[i] % 32];
    if (!db.prepare('SELECT 1 FROM users WHERE parent_code=?').get(c)) return c;
  }
}
function startSession(res, userId) {
  const tok = crypto.randomBytes(32).toString('hex');
  db.prepare('INSERT INTO sessions(token_hash,user_id,expires) VALUES(?,?,?)').run(sha(tok), userId, Date.now() + 30 * 864e5);
  res.append('Set-Cookie', `sid=${tok}; HttpOnly; SameSite=Lax; Path=/; Max-Age=${30 * 86400}${PROD ? '; Secure' : ''}`);
}
function upsertUser({ sub, email, name, picture, lang }) {
  let u = db.prepare('SELECT * FROM users WHERE google_sub=?').get(sub);
  if (!u) {
    const info = db.prepare('INSERT INTO users(google_sub,email,name,picture,parent_code,created_at,lang) VALUES(?,?,?,?,?,?,?)').run(sub, email, name, picture, newParentCode(), Date.now(), lang === 'uz' ? 'uz' : 'ru');
    u = db.prepare('SELECT * FROM users WHERE id=?').get(info.lastInsertRowid);
  } else {
    db.prepare('UPDATE users SET name=?, picture=?, email=? WHERE id=?').run(name, picture, email, u.id);
  }
  return u;
}
function auth(req, res, next) {
  const tok = cookies(req).sid;
  if (tok) {
    const s = db.prepare('SELECT user_id FROM sessions WHERE token_hash=? AND expires>?').get(sha(tok), Date.now());
    if (s) req.user = db.prepare('SELECT * FROM users WHERE id=?').get(s.user_id);
  }
  if (!req.user) return fail(req, res, 401, 'login');
  next();
}
const publicUser = u => ({ name: u.name, email: u.email, picture: u.picture, direction: u.direction, parentCode: u.parent_code, plan: u.plan, planUntil: u.plan_until, active: isActive(u), lang: u.lang, tutor: personaOf(u.teacher_style), tutorChosen: !!u.tutor_chosen, createdAt: u.created_at });
const canAccess = (u, c) => isActive(u) || c.index < FREE_CHAPTERS;
const accessFn = u => tid => !!own(TOPIC, tid) && canAccess(u, TOPIC[tid].chapter);
function contentError(req, res, e) {
  console.error('content:', e.message);
  fail(req, res, 503, e.message === 'NO_AI' ? 'noMaterial' : 'genFail');
}
// Админ-доступ: токен сравнивается за постоянное время, неудачные попытки ограничены
function isAdmin(req) {
  const want = process.env.ADMIN_TOKEN || '';
  if (!want) return false;
  const a = Buffer.from(String(req.headers['x-admin-token'] || '')), b = Buffer.from(want);
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}
function admin(req, res, next) {
  const key = 'admin-fail:' + req.ip, now = Date.now();
  if ((hits.get(key) || []).filter(t => now - t < 600e3).length >= 10) return res.status(429).json({ error: 'Слишком много неудачных попыток. Подождите 10 минут.' });
  if (!isAdmin(req)) { limited(key, Infinity, 600e3); return res.status(403).json({ error: 'Нет доступа' }); }
  next();
}

/* ---------- публичное ---------- */
app.get('/api/config', (req, res) => res.json({ googleClientId: GID, dev: DEV, payme: payme.enabled(), card: billing.cardEnabled(), telegram: !!tg.botName(), chat: ai.enabled(), chatLimits: chatLimits() }));
app.get('/api/catalog', (req, res) => res.json(localized(langOf(req))));

/* ---------- вход ---------- */
app.post('/api/auth/google', async (req, res) => {
  if (!gclient) return fail(req, res, 500, 'gOff');
  if (limited('auth:' + req.ip, 20, 60e3)) return fail(req, res, 429, 'many');
  try {
    const t = await gclient.verifyIdToken({ idToken: String(req.body.credential || ''), audience: GID });
    const p = t.getPayload();
    if (!p.email_verified) return fail(req, res, 401, 'emailNV');
    const u = upsertUser({ sub: 'g:' + p.sub, email: String(p.email).toLowerCase(), name: p.name || p.email, picture: p.picture || '', lang: langOf(req) });
    startSession(res, u.id); res.json({ ok: true });
  } catch (e) { fail(req, res, 401, 'gFail'); }
});
app.post('/api/auth/dev', (req, res) => {
  if (!DEV) return res.status(404).end();
  const email = String(req.body.email || '').trim().toLowerCase(), name = String(req.body.name || '').trim().slice(0, 60);
  if (!name || !/^\S+@\S+\.\S+$/.test(email)) return fail(req, res, 400, 'nameEmail');
  const u = upsertUser({ sub: 'dev:' + email, email, name, picture: '', lang: langOf(req) });
  startSession(res, u.id); res.json({ ok: true });
});
app.post('/api/auth/logout', (req, res) => {
  const tok = cookies(req).sid;
  if (tok) db.prepare('DELETE FROM sessions WHERE token_hash=?').run(sha(tok));
  res.append('Set-Cookie', 'sid=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0');
  res.json({ ok: true });
});

/* ---------- профиль и прогресс ---------- */
app.get('/api/me', auth, (req, res) => res.json({ user: publicUser(req.user), tgLink: tg.link(req.user.parent_code) }));
app.post('/api/direction', auth, (req, res) => {
  if (!DIRECTIONS.some(d => d.id === req.body.direction)) return fail(req, res, 400, 'badDir');
  db.prepare('UPDATE users SET direction=? WHERE id=?').run(req.body.direction, req.user.id);
  res.json({ ok: true });
});
app.post('/api/lang', auth, (req, res) => {
  if (!['ru', 'uz'].includes(req.body.lang)) return fail(req, res, 400, 'badLang');
  db.prepare('UPDATE users SET lang=? WHERE id=?').run(req.body.lang, req.user.id);
  res.json({ ok: true });
});
// ---------- первичная диагностика ----------
function diagnosticStatus(user, lang) {
  const dir = user.direction ? DIRECTIONS.find(d => d.id === user.direction) : null;
  const subjects = dir ? dir.subjects.map(sid => {
    const row = db.prepare('SELECT score, done FROM diagnostics WHERE user_id=? AND subject_id=? AND done=1 ORDER BY completed_at DESC LIMIT 1').get(user.id, sid);
    return { id: sid, name: subjName(sid, lang), score: row ? row.score : null, done: !!row };
  }) : [];
  const next = subjects.find(s => !s.done);
  return { done: subjects.length > 0 && !next, subjects, next: next ? next.id : null };
}

app.get('/api/diagnostic/status', auth, (req, res) => res.json(diagnosticStatus(req.user, langOf(req))));

app.post('/api/diagnostic/start', auth, async (req, res) => {
  if (!req.user.direction) return fail(req, res, 400, 'badDir');
  if (limited('diag:' + req.user.id, 12, 3600e3)) return fail(req, res, 429, 'tooTests');
  const lang = langOf(req), d = DIRECTIONS.find(x => x.id === req.user.direction);
  const asked = String(req.body.subjectId || '');
  const sid = d.subjects.includes(asked) ? asked : diagnosticStatus(req.user, lang).next;
  if (!sid) return res.json({ done: true, status: diagnosticStatus(req.user, lang) });
  const old = db.prepare('SELECT * FROM diagnostics WHERE user_id=? AND subject_id=? AND done=0 ORDER BY created_at DESC LIMIT 1').get(req.user.id, sid);
  if (old) {
    const qs = JSON.parse(old.qs), ans = JSON.parse(old.answers), i = ans.length;
    if (i < qs.length) return res.json({ diagnosticId: old.id, subjectId: sid, subjectName: subjName(sid, lang), total: qs.length, index: i, q: qs[i].q, options: qs[i].opts.map(o => o.t), done: false });
  }
  try {
    const topics = SUBJECTS[sid].chapters.flatMap(c => c.topics.map(t => t.id));
    const by = await loadTopicQs(topics, lang);
    const picked = pickFrom(topics.map(t => by[t]), 20, new Set());
    if (picked.length < 12) return fail(req, res, 503, 'noQuestions');
    const qs = shuffle(picked).slice(0, Math.min(20, picked.length)).map(q => ({ id:q.id, t:q.t, q:q.q, e:q.e, opts:shuffle(q.o.map((t,i)=>({t,ok:i===q.a,m:(q.m&&q.m[i])||''}))) }));
    const id = crypto.randomUUID(), now = Date.now();
    db.prepare('INSERT INTO diagnostics(id,user_id,subject_id,qs,answers,created_at) VALUES(?,?,?,?,?,?)').run(id, req.user.id, sid, JSON.stringify(qs), '[]', now);
    res.json({ diagnosticId:id, subjectId:sid, subjectName:subjName(sid,lang), total:qs.length, index:0, q:qs[0].q, options:qs[0].opts.map(o=>o.t), done:false });
  } catch(e) { contentError(req,res,e); }
});

app.post('/api/diagnostic/answer', auth, (req, res) => {
  const d = db.prepare('SELECT * FROM diagnostics WHERE id=? AND user_id=?').get(String(req.body.diagnosticId||''), req.user.id);
  if (!d) return fail(req,res,404,'noTest');
  const qs = JSON.parse(d.qs), ans = JSON.parse(d.answers), i = ans.length, choice = Number(req.body.choice);
  const requested = Number(req.body.index);
  if (Number.isInteger(requested) && requested !== i) return res.status(409).json({ error:m(req,'resync'), sync:{ index:i, q:qs[i]?.q, options:qs[i]?.opts.map(o=>o.t) } });
  if (d.done) return res.status(409).json({ error:m(req,'resync'), sync:{done:true,result:{subjectId:d.subject_id,score:d.score}} });
  if (i >= qs.length || !Number.isInteger(choice) || choice<0 || choice>=qs[i].opts.length) return fail(req,res,400,'badChoice');
  const q=qs[i], correctIndex=q.opts.findIndex(o=>o.ok), correct=choice===correctIndex;
  ans.push(choice);
  db.prepare('UPDATE diagnostics SET answers=? WHERE id=?').run(JSON.stringify(ans),d.id);
  db.prepare('INSERT INTO answer_log(user_id,test_id,chapter_id,topic_id,qid,question,chosen,correct_text,is_correct,misconception,ms,created_at,helped) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)')
    .run(req.user.id,d.id,'diagnostic:'+d.subject_id,q.t,q.id,q.q,q.opts[choice].t,q.opts[correctIndex].t,correct?1:0,correct?null:(q.opts[choice].m||null),0,Date.now(),0);
  if (i < qs.length-1) return res.json({index:i,correct,correctIndex,explanation:q.e,next:{index:i+1,q:qs[i+1].q,options:qs[i+1].opts.map(o=>o.t)}});
  const per={}; let right=0;
  qs.forEach((x,j)=>{ const p=per[x.t]||(per[x.t]={n:0,r:0}); p.n++; if(x.opts[ans[j]].ok){right++;p.r++;} });
  const perOut=[];
  db.transaction(()=>{
    const setM=db.prepare('INSERT INTO mastery(user_id,topic_id,value,peak) VALUES(?,?,?,?) ON CONFLICT(user_id,topic_id) DO UPDATE SET value=excluded.value, peak=MAX(COALESCE(mastery.peak,0),excluded.value)');
    for(const [tid,p] of Object.entries(per)){ const score=Math.round(100*p.r/p.n); setM.run(req.user.id,tid,score,score); perOut.push({topicId:tid,name:topicName(tid,langOf(req)),score}); }
    const score=Math.round(100*right/qs.length);
    db.prepare('UPDATE diagnostics SET done=1,score=?,completed_at=? WHERE id=?').run(score,Date.now(),d.id);
    db.prepare('UPDATE users SET last_active=? WHERE id=?').run(Date.now(),req.user.id);
    gamify.addActivity(req.user.id,10);
  })();
  const status=diagnosticStatus(req.user,langOf(req));
  const allDone=status.done;
  const newBadges=allDone?gamify.checkBadges(req.user,{diagnostic:true}):[];
  res.json({index:i,correct,correctIndex,explanation:q.e,result:{subjectId:d.subject_id,subjectName:subjName(d.subject_id,langOf(req)),score:Math.round(100*right/qs.length),right,total:qs.length,per:perOut,allDone,newBadges,status}});
});

app.get('/api/progress', auth, (req, res) => {
  const p = progressFor(req.user.id, req.user.direction, langOf(req), accessFn(req.user));
  res.json({ overall: p.overall, subjects: p.subjects, dueCount: p.dueTopics.length, lockedDue: p.lockedDue, streak: gamify.streakOf(req.user.id), weekPoints: gamify.pointsOf(req.user.id).week });
});
app.post('/api/parent-code/regenerate', auth, (req, res) => {
  const code = newParentCode();
  db.transaction(() => {
    db.prepare('UPDATE users SET parent_code=? WHERE id=?').run(code, req.user.id);
    db.prepare('DELETE FROM tg_links WHERE user_id=?').run(req.user.id); // старый доступ закрыт
  })();
  res.json({ code, tgLink: tg.link(code) });
});
// Удаление аккаунта: учебные данные стираются, профиль обезличивается. Платёжные записи остаются для отчётности.
app.post('/api/account/delete', auth, (req, res) => {
  if (req.body.confirm !== true) return fail(req, res, 400, 'deleteConfirm');
  const u = req.user, anon = 'deleted:' + u.id + ':' + crypto.randomBytes(6).toString('hex');
  const files = db.prepare('SELECT receipt FROM orders WHERE user_id=? AND receipt IS NOT NULL').all(u.id).map(r => r.receipt);
  db.transaction(() => {
    db.prepare('UPDATE orders SET receipt=NULL, note=NULL WHERE user_id=?').run(u.id); // суммы и даты остаются для отчётности
    db.prepare("UPDATE users SET google_sub=?, email=NULL, name='—', picture='', nickname=NULL, nickname_lc=NULL, leaderboard=0, parent_code=?, direction=NULL WHERE id=?").run(anon, anon, u.id);
    for (const t of ['sessions', 'tg_links', 'answer_log', 'help_chat', 'tutor_chat', 'reports', 'used_q', 'tests', 'mastery', 'topic_review', 'activity_days', 'achievements', 'style_wins', 'topic_style', 'attempts']) {
      db.prepare(`DELETE FROM ${t} WHERE user_id=?`).run(u.id);
    }
  })();
  for (const f of files) fs.rm(path.join(RECEIPTS, path.basename(f)), { force: true }, () => {});
  res.append('Set-Cookie', 'sid=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0');
  res.json({ ok: true });
});

/* ---------- наставник ---------- */
// Сводка для приветствия: интерфейс сам собирает из неё фразу на нужном языке и в голосе наставника
function nextChapter(user, p, lang) {
  if (!p.direction) return null;
  for (let i = 0; i < 6; i++) for (const sid of p.direction.subjects) {
    const c = SUBJECTS[sid].chapters[i];
    if (c && !p.subjects[sid].chapters[i].passed && canAccess(user, c)) return { chapterId: c.id, title: chTitle(c.id, lang), subject: sid, subjectName: subjName(sid, lang) };
  }
  return null;
}
function tutorBrief(user, lang) {
  const p = progressFor(user.id, user.direction, lang, accessFn(user));
  const last = db.prepare('SELECT chapter_id, correct, total, passed, weak, review, created_at FROM attempts WHERE user_id=? ORDER BY id DESC LIMIT 1').get(user.id);
  const weak = last && Date.now() - last.created_at < 3 * DAY ? JSON.parse(last.weak).filter(id => own(TOPIC, id) && accessFn(user)(id)) : [];
  return {
    firstName: String(user.name || '').trim().split(/\s+/)[0] || '',
    hour: new Date(Date.now() + 5 * 3600e3).getUTCHours(),
    overall: p.overall, dueCount: p.dueTopics.length, lockedDue: p.lockedDue,
    dueTopics: p.dueTopics.slice(0, 2).map(d => topicName(d.topicId, lang)),
    weakTopic: weak.length ? { id: weak[0], name: topicName(weak[0], lang), chapterId: TOPIC[weak[0]].chapter.id, subject: TOPIC[weak[0]].subject } : null,
    last: last ? { title: own(CH, last.chapter_id) ? chTitle(last.chapter_id, lang) : '', at: last.created_at, passed: !!last.passed, review: !!last.review, correct: last.correct, total: last.total } : null,
    next: nextChapter(user, p, lang), streak: gamify.streakOf(user.id)
  };
}
// «Что наставник помнит»: только реальные данные ученика
function tutorMemory(user, lang) {
  const p = progressFor(user.id, user.direction, lang);
  const one = (sql, ...a) => db.prepare(sql).get(...a).c;
  const strong = [], weak = [];
  for (const [tid, v] of Object.entries(p.mastery)) {
    if (!own(TOPIC, tid) || (p.direction && !p.direction.subjects.includes(TOPIC[tid].subject))) continue;
    if (v >= 80) strong.push([tid, v]); else if (v < 60) weak.push([tid, v]);
  }
  const best = db.prepare('SELECT method FROM style_wins WHERE user_id=? ORDER BY wins DESC LIMIT 1').get(user.id);
  return {
    days: one('SELECT COUNT(*) c FROM activity_days WHERE user_id=?', user.id),
    tests: one('SELECT COUNT(*) c FROM attempts WHERE user_id=?', user.id),
    mistakes: one('SELECT COUNT(*) c FROM answer_log WHERE user_id=? AND is_correct=0', user.id),
    questions: one("SELECT COUNT(*) c FROM tutor_chat WHERE user_id=? AND role='user'", user.id) + one("SELECT COUNT(*) c FROM help_chat WHERE user_id=? AND role='assistant'", user.id),
    strong: strong.sort((a, b) => b[1] - a[1]).slice(0, 3).map(([t, v]) => ({ name: topicName(t, lang), pct: v })),
    weak: weak.sort((a, b) => a[1] - b[1]).slice(0, 3).map(([t, v]) => ({ name: topicName(t, lang), pct: v })),
    method: best ? best.method : null
  };
}
app.get('/api/tutor', auth, (req, res) => {
  const lang = langOf(req);
  res.json({ persona: personaOf(req.user.teacher_style), chosen: !!req.user.tutor_chosen, brief: tutorBrief(req.user, lang), memory: tutorMemory(req.user, lang), chat: ai.enabled() });
});
app.post('/api/tutor', auth, (req, res) => {
  if (!own(PERSONAS, req.body.persona)) return fail(req, res, 400, 'badPersona');
  db.prepare('UPDATE users SET teacher_style=?, tutor_chosen=1 WHERE id=?').run(req.body.persona, req.user.id);
  res.json({ ok: true });
});

/* ---------- чат с наставником ---------- */
function chatLimit(user) {
  const lim = chatLimits();
  const used = db.prepare("SELECT COUNT(*) c FROM tutor_chat WHERE user_id=? AND role='user' AND created_at>=?").get(user.id, dayStart()).c;
  return { used, limit: isActive(user) ? lim.paid : lim.free };
}
app.get('/api/chat', auth, (req, res) => {
  const rows = db.prepare('SELECT role, text, created_at FROM tutor_chat WHERE user_id=? ORDER BY id DESC LIMIT 60').all(req.user.id).reverse();
  res.json({ messages: rows.map(r => ({ role: r.role, text: r.text, at: r.created_at })), limit: chatLimit(req.user), enabled: ai.enabled() });
});
function chatHistory(userId) {
  const rows = db.prepare('SELECT role, text FROM tutor_chat WHERE user_id=? ORDER BY id DESC LIMIT 12').all(userId).reverse();
  const msgs = [];
  for (const r of rows) {
    const role = r.role === 'assistant' ? 'assistant' : 'user';
    if (!msgs.length && role !== 'user') continue;          // история должна начинаться с ученика
    if (msgs.length && msgs[msgs.length - 1].role === role) msgs[msgs.length - 1].content += '\n\n' + r.text;
    else msgs.push({ role, content: r.text });
  }
  if (msgs.length && msgs[msgs.length - 1].role === 'user') msgs.pop(); // прошлый вопрос без ответа не дублируем
  return msgs;
}
function studentContext(user, lang, chapterId) {
  const p = progressFor(user.id, user.direction, lang, accessFn(user)), mem = tutorMemory(user, lang);
  const mistakes = db.prepare('SELECT question, chosen, correct_text FROM answer_log WHERE user_id=? AND is_correct=0 ORDER BY id DESC LIMIT 3').all(user.id)
    .map(r => ({ question: r.question.slice(0, 220), chose: r.chosen.slice(0, 80), correct: r.correct_text.slice(0, 80) }));
  const ctx = {
    direction: p.direction ? localized(lang).directions.find(d => d.id === p.direction.id).name : null,
    subjects: p.direction ? p.direction.subjects.map(s => ({ name: p.subjects[s].name, readiness: p.subjects[s].pct + '%' })) : [],
    weakTopics: mem.weak.map(w => w.name), dueForReview: p.dueTopics.slice(0, 3).map(d => topicName(d.topicId, lang)), recentMistakes: mistakes
  };
  const c = own(CH, chapterId);
  if (c && canAccess(user, c)) ctx.currentLesson = { chapter: chTitle(c.id, lang), subject: subjName(c.subject, lang), topics: c.topics.map(t => topicName(t.id, lang)) };
  return ctx;
}
const STREAM_ERR = '\u001E'; // разделитель: после него идёт текст ошибки, если связь с ИИ прервалась
app.post('/api/chat', auth, async (req, res) => {
  if (!ai.enabled()) return fail(req, res, 503, 'chatOff');
  const text = String(req.body.text || '').trim().slice(0, 600), lang = langOf(req);
  if (!text) return fail(req, res, 400, 'chatEmpty');
  if (limited('chat:' + req.user.id, 30, 3600e3)) return fail(req, res, 429, 'tooReq');
  const lim = chatLimit(req.user);
  if (lim.used >= lim.limit) return res.status(429).json({ error: m(req, isActive(req.user) ? 'chatMaxPaid' : 'chatMaxFree'), limit: lim });
  const system = ai.chatSystem({ style: req.user.teacher_style, lang, student: studentContext(req.user, lang, req.body.chapterId) });
  const messages = [...chatHistory(req.user.id), { role: 'user', content: text }];
  // Вопрос записывается сразу: так параллельные запросы не обойдут дневной лимит. Без ответа он удаляется.
  const qId = db.prepare('INSERT INTO tutor_chat(user_id,role,text,created_at) VALUES(?,?,?,?)').run(req.user.id, 'user', text, Date.now()).lastInsertRowid;
  const drop = () => db.prepare('DELETE FROM tutor_chat WHERE id=?').run(qId);
  const gen = ai.stream({ system, messages });
  let first, closed = false;
  res.on('close', () => { closed = true; });
  try { first = await gen.next(); } catch (e) { console.error('chat:', e.message); drop(); return closed ? undefined : fail(req, res, 503, 'chatOff'); }
  if (closed) { gen.return().catch(() => {}); drop(); return; } // ученик ушёл до первого слова: генерацию останавливаем
  res.set({ 'Content-Type': 'text/plain; charset=utf-8', 'Cache-Control': 'no-cache, no-transform', 'X-Accel-Buffering': 'no', 'X-Chat-Used': String(lim.used + 1), 'X-Chat-Limit': String(lim.limit) });
  res.flushHeaders();
  let out = '';
  try {
    if (!first.done && first.value) { out += first.value; res.write(first.value); }
    if (!first.done) for await (const piece of gen) { if (closed) break; out += piece; res.write(piece); }
  } catch (e) {
    console.error('chat stream:', e.message);
    if (!closed) res.write(STREAM_ERR + m(req, 'chatOff'));
  }
  if (out.trim()) db.prepare('INSERT INTO tutor_chat(user_id,role,text,created_at) VALUES(?,?,?,?)').run(req.user.id, 'assistant', out.trim().slice(0, 6000), Date.now());
  else drop();
  res.end();
});

/* ---------- обучение ---------- */
app.get('/api/chapter/:id', auth, async (req, res) => {
  const c = own(CH, req.params.id), lang = langOf(req);
  if (!c) return fail(req, res, 404, 'noChapter');
  if (!canAccess(req.user, c)) return fail(req, res, 402, 'needSub');
  try { res.json({ id: c.id, title: chTitle(c.id, lang), subject: c.subject, ...(await content.getLesson(c.id, lang)) }); } catch (e) { contentError(req, res, e); }
});
app.get('/api/mini', auth, async (req, res) => {
  const lang = langOf(req), access = accessFn(req.user);
  const ids = [...new Set(String(req.query.topics || '').split(','))].filter(access).slice(0, 4); // только доступные ученику темы
  if (!ids.length) return fail(req, res, 404, 'notFound');
  try {
    const usePersonal = ai.enabled();
    const out = await Promise.all(ids.map(async id => {
      let item = null;
      if (usePersonal && !limited('mini:' + req.user.id, 20, 3600e3)) {
        try { item = await personalMini(req.user, id, lang); } catch (e) { console.error('personal mini:', e.message); }
      }
      if (!item) item = { ...(await content.getMini(id, lang)), personal: false, method: null };
      return { id, name: topicName(id, lang), ...item };
    }));
    res.json(out);
  } catch (e) { contentError(req, res, e); }
});

// Персональный мини-урок: учитывает конкретные ошибки ученика и меняет способ объяснения при повторных неудачах
function pickMethod(userId, fails, last) {
  const best = db.prepare('SELECT method FROM style_wins WHERE user_id=? ORDER BY wins DESC LIMIT 1').get(userId);
  const order = best ? [best.method, ...ai.METHODS.filter(x => x !== best.method)] : ai.METHODS;
  let method = order[(Math.max(fails, 1) - 1) % order.length]; // по кругу через все способы
  if (method === last) method = order[(order.indexOf(method) + 1) % order.length]; // и никогда тот же, что в прошлый раз
  return method;
}
async function personalMini(user, topicId, lang) {
  const wrong = db.prepare('SELECT question, chosen, correct_text, misconception FROM answer_log WHERE user_id=? AND topic_id=? AND is_correct=0 ORDER BY id DESC LIMIT 4').all(user.id, topicId)
    .map(w => ({ q: w.question, chosen: w.chosen, correct: w.correct_text, why: w.misconception || undefined }));
  if (!wrong.length) return null;
  const st = db.prepare('SELECT fails, method FROM topic_style WHERE user_id=? AND topic_id=?').get(user.id, topicId) || { fails: 1, method: null };
  const fails = Math.max(st.fails, 1), method = pickMethod(user.id, fails, st.method);
  const r = await ai.genPersonalMini({ topic: TOPIC[topicId], lang, method, wrong, fails, style: user.teacher_style });
  db.prepare('INSERT INTO topic_style(user_id,topic_id,fails,method) VALUES(?,?,?,?) ON CONFLICT(user_id,topic_id) DO UPDATE SET method=excluded.method').run(user.id, topicId, fails, method);
  return { ...r, personal: true, method };
}

/* ---------- тесты ---------- */
const usedSet = uid => new Set(db.prepare('SELECT qid FROM used_q WHERE user_id=?').all(uid).map(r => r.qid));
// По очереди из каждой группы, сначала невиденные вопросы; если в группе не хватает — добираем из остальных
function pickFrom(groups, n, used) {
  const queues = groups.map(g => [...shuffle(g.filter(q => !used.has(q.id))), ...shuffle(g.filter(q => used.has(q.id)))]);
  const out = [];
  while (out.length < n && queues.some(q => q.length)) for (const q of queues) if (q.length && out.length < n) out.push(q.shift());
  return out;
}
async function loadTopicQs(topicIds, lang) {
  const blocked = new Set(db.prepare('SELECT qid FROM blocked_q').all().map(r => r.qid));
  const by = {};
  for (const tid of topicIds) {
    const all = (await content.getQuestions(tid, lang)).map(q => ({ ...q, t: tid }));
    by[tid] = all.filter(q => !blocked.has(q.id)); // скрытые вопросы не показываются никогда
    if (by[tid].length < 4) content.topUp(tid, lang); // ИИ в фоне досоздаст новые
  }
  return by;
}
function createTest(user, chapterId, picked, { retest = 0, review = 0 } = {}) {
  const qs = shuffle(picked).map(q => ({ id: q.id, t: q.t, q: q.q, e: q.e, opts: shuffle(q.o.map((t, i) => ({ t, ok: i === q.a, m: (q.m && q.m[i]) || '' }))) }));
  const id = crypto.randomUUID(), now = Date.now();
  db.prepare('INSERT INTO tests(id,user_id,chapter_id,qs,retest,created_at,qts,review) VALUES(?,?,?,?,?,?,?,?)').run(id, user.id, chapterId, JSON.stringify(qs), retest, now, now, review);
  return { testId: id, total: qs.length, retest: !!retest, review: !!review, index: 0, q: qs[0].q, options: qs[0].opts.map(o => o.t), chapterId };
}

app.post('/api/test/start', auth, async (req, res) => {
  if (req.body.review) return startReview(req, res);
  const c = own(CH, req.body.chapterId), lang = langOf(req);
  if (!c) return fail(req, res, 404, 'noChapter');
  if (!canAccess(req.user, c)) return fail(req, res, 402, 'needSub');
  if (limited('test:' + req.user.id, 30, 3600e3)) return fail(req, res, 429, 'tooTests');
  try {
    const used = usedSet(req.user.id);
    const by = await loadTopicQs(c.topics.map(t => t.id), lang);
    let picked = null, retest = 0;
    if (req.body.retest) {
      const last = db.prepare('SELECT weak FROM attempts WHERE user_id=? AND chapter_id=? AND review=0 ORDER BY id DESC LIMIT 1').get(req.user.id, c.id);
      const weak = last ? JSON.parse(last.weak) : [];
      if (weak.length) { // повторный тест засчитывается только после реальной неудачи
        retest = 1;
        picked = pickFrom(c.topics.filter(t => weak.includes(t.id)).map(t => by[t.id]), TEST_LEN, used);
        if (picked.length < TEST_LEN) picked = picked.concat(pickFrom(c.topics.filter(t => !weak.includes(t.id)).map(t => by[t.id]), TEST_LEN - picked.length, used));
      }
    }
    if (!picked) picked = pickFrom(c.topics.map(t => by[t.id]), TEST_LEN, used);
    if (picked.length < 2) return fail(req, res, 503, 'noQuestions');
    res.json(createTest(req.user, c.id, picked, { retest }));
  } catch (e) { contentError(req, res, e); }
});

// Тест-повторение: до двух самых просроченных доступных тем (или темы, переданные явно — после разбора ошибок)
async function startReview(req, res) {
  const lang = langOf(req), access = accessFn(req.user);
  if (limited('test:' + req.user.id, 30, 3600e3)) return fail(req, res, 429, 'tooTests');
  const asked = Array.isArray(req.body.topics) ? [...new Set(req.body.topics.map(String))].filter(access).slice(0, 2) : [];
  const topics = asked.length ? asked : progressFor(req.user.id, req.user.direction, lang, access).dueTopics.slice(0, 2).map(d => d.topicId);
  if (!topics.length) return fail(req, res, 400, 'noReview');
  try {
    const by = await loadTopicQs(topics, lang);
    const picked = pickFrom(topics.map(t => by[t]), TEST_LEN, usedSet(req.user.id));
    if (picked.length < 2) return fail(req, res, 503, 'noQuestions');
    res.json(createTest(req.user, TOPIC[topics[0]].chapter.id, picked, { review: 1 }));
  } catch (e) { contentError(req, res, e); }
}

function finalize(user, t, qs, ans, lang) {
  const before = progressFor(user.id, user.direction).overall;
  const ul = user.lang === 'uz' ? 'uz' : 'ru';
  const helped = new Set(JSON.parse(t.helped || '[]'));
  const per = {};
  let right = 0, solo = 0, assisted = 0;
  qs.forEach((q, i) => {
    const p = per[q.t] || (per[q.t] = { n: 0, r: 0, credit: 0 });
    p.n++;
    if (q.opts[ans[i]].ok) { right++; p.r++; if (helped.has(i)) { assisted++; p.credit += 0.5; } else { solo++; p.credit += 1; } }
  });
  // Глава засчитывается за самостоятельные ответы; ответ после подсказки даёт половину балла
  const total = qs.length, need = Math.max(1, Math.round(total * PASS_RATIO)), passed = solo >= need, weak = [];
  const getM = db.prepare('SELECT value, peak FROM mastery WHERE user_id=? AND topic_id=?');
  const setM = db.prepare('INSERT INTO mastery(user_id,topic_id,value,peak) VALUES(?,?,?,?) ON CONFLICT(user_id,topic_id) DO UPDATE SET value=excluded.value, peak=excluded.peak');
  const perOut = [];
  let gain = 0, overdue = 0, bonus = 0, points = 0;
  db.transaction(() => {
    for (const [tid, p] of Object.entries(per)) {
      const rev = db.prepare('SELECT box, due_at FROM topic_review WHERE user_id=? AND topic_id=?').get(user.id, tid);
      const row = getM.get(user.id, tid) || { value: 0, peak: 0 };
      const dueAt = rev && rev.due_at;
      const old = decayed(row.value, dueAt), peak = decayed(row.peak == null ? row.value : row.peak, dueAt), s = p.credit / p.n;
      const nv = Math.round(old + (s * 100 - old) * 0.7);
      setM.run(user.id, tid, nv, Math.max(peak, nv));
      // очки только за новый лучший уровень темы: «провалить нарочно и пройти снова» ничего не даёт,
      // а вернуть забытое (пик тоже «забывается») — даёт
      gain += Math.max(0, nv - Math.max(old, peak));
      if (rev && rev.due_at < Date.now()) overdue = Math.max(overdue, (Date.now() - rev.due_at) / DAY);
      // расписание повторений: успех отодвигает следующий срок, провал возвращает тему на завтра
      {
        const now = Date.now(); let box = rev ? rev.box : 0, due = rev ? rev.due_at : now;
        if (s < 0.75) { box = 0; due = now + INTERVALS[0] * DAY; }
        else if (!rev) { box = 1; due = now + INTERVALS[1] * DAY; }
        else if (rev.due_at <= now) { box = Math.min(rev.box + 1, INTERVALS.length - 1); due = now + INTERVALS[box] * DAY; }
        db.prepare('INSERT INTO topic_review(user_id,topic_id,box,due_at,last_at) VALUES(?,?,?,?,?) ON CONFLICT(user_id,topic_id) DO UPDATE SET box=excluded.box, due_at=excluded.due_at, last_at=excluded.last_at').run(user.id, tid, box, due, now);
      }
      const ts = db.prepare('SELECT fails, method FROM topic_style WHERE user_id=? AND topic_id=?').get(user.id, tid) || { fails: 0, method: null };
      if (s < 0.75) {
        weak.push(tid);
        db.prepare('INSERT INTO topic_style(user_id,topic_id,fails,method) VALUES(?,?,?,?) ON CONFLICT(user_id,topic_id) DO UPDATE SET fails=excluded.fails').run(user.id, tid, ts.fails + 1, ts.method);
      } else {
        if (ts.fails > 0 && ts.method) db.prepare('INSERT INTO style_wins(user_id,method,wins) VALUES(?,?,1) ON CONFLICT(user_id,method) DO UPDATE SET wins=wins+1').run(user.id, ts.method);
        db.prepare('INSERT INTO topic_style(user_id,topic_id,fails,method) VALUES(?,?,0,NULL) ON CONFLICT(user_id,topic_id) DO UPDATE SET fails=0, method=NULL').run(user.id, tid);
      }
      perOut.push({ topicId: tid, name: topicName(tid, lang), right: p.r, n: p.n, mastery: nv });
    }
    for (const q of qs) db.prepare('INSERT OR IGNORE INTO used_q(user_id,qid) VALUES(?,?)').run(user.id, q.id);
    if (passed && !t.review && !db.prepare('SELECT 1 FROM attempts WHERE user_id=? AND chapter_id=? AND passed=1 AND review=0').get(user.id, t.chapter_id)) bonus = 20;
    db.prepare('INSERT INTO attempts(user_id,chapter_id,correct,total,passed,retest,weak,created_at,review,solo) VALUES(?,?,?,?,?,?,?,?,?,?)').run(user.id, t.chapter_id, right, total, passed ? 1 : 0, t.retest, JSON.stringify(weak), Date.now(), t.review ? 1 : 0, solo);
    db.prepare('UPDATE tests SET done=1, answers=? WHERE id=?').run(JSON.stringify(ans), t.id);
    db.prepare('UPDATE users SET last_active=? WHERE id=?').run(Date.now(), user.id);
    points = Math.round(gain / 2) + bonus;
    gamify.addActivity(user.id, points);
  })();
  const after = progressFor(user.id, user.direction).overall;
  const newBadges = gamify.checkBadges(user, { right: solo, total, passed, retest: !!t.retest, review: !!t.review, overdue });
  const result = { right, solo, assisted, need, total, passed, before, after, points, newBadges, review: !!t.review, streak: gamify.streakOf(user.id).current, per: perOut, weak: weak.map(id => ({ id, name: topicName(id, lang) })) };
  db.prepare('UPDATE tests SET result=? WHERE id=?').run(JSON.stringify(result), t.id);
  const title = own(CH, t.chapter_id) ? chTitle(t.chapter_id, ul) : t.chapter_id;
  tg.notify(user.id, t.review ? tg.TM[ul].review(user.name, right, total, before, after) : tg.TM[ul].report(user.name, title, right, total, passed, before, after)).catch(() => {});
  return result;
}

// Ответ на вопрос (вопрос i): тот же ответ на тот же вопрос можно прислать повторно — сервер вернёт то же самое
function replyFor(t, qs, ans, i, result) {
  const q = qs[i], choice = ans[i], correctIndex = q.opts.findIndex(o => o.ok);
  const out = { index: i, correct: choice === correctIndex, correctIndex, explanation: q.e, helped: JSON.parse(t.helped || '[]').includes(i) };
  if (!out.correct && q.opts[choice] && q.opts[choice].m) out.hint = q.opts[choice].m;
  if (i < qs.length - 1) out.next = { index: i + 1, q: qs[i + 1].q, options: qs[i + 1].opts.map(o => o.t) };
  else out.result = result || (t.result ? JSON.parse(t.result) : null);
  return out;
}
function resync(req, res, t, qs, ans) {
  const i = ans.length;
  const fresh = db.prepare('SELECT done, result FROM tests WHERE id=?').get(t.id);
  res.status(409).json({ error: m(req, 'resync'), sync: fresh.done || i >= qs.length ? { done: true, result: fresh.result ? JSON.parse(fresh.result) : null } : { index: i, q: qs[i].q, options: qs[i].opts.map(o => o.t), total: qs.length } });
}
app.post('/api/test/answer', auth, (req, res) => {
  const t = db.prepare('SELECT * FROM tests WHERE id=? AND user_id=?').get(String(req.body.testId || ''), req.user.id);
  if (!t) return fail(req, res, 404, 'noTest');
  const qs = JSON.parse(t.qs), ans = JSON.parse(t.answers), choice = Number(req.body.choice);
  const hasIndex = req.body.index !== undefined && req.body.index !== null, index = Number(req.body.index);
  if (hasIndex && Number.isInteger(index) && index >= 0 && index < ans.length) {
    return ans[index] === choice ? res.json(replyFor(t, qs, ans, index)) : resync(req, res, t, qs, ans); // повтор после потери ответа
  }
  if (t.done) return fail(req, res, 404, 'noTest');
  const i = ans.length;
  if (hasIndex && index !== i) return resync(req, res, t, qs, ans);
  if (!Number.isInteger(choice) || choice < 0 || choice >= qs[i].opts.length) return fail(req, res, 400, 'badChoice');
  ans.push(choice);
  const q = qs[i], correctIndex = q.opts.findIndex(o => o.ok), correct = choice === correctIndex, now = Date.now();
  const helped = JSON.parse(t.helped || '[]').includes(i) ? 1 : 0;
  db.prepare('INSERT INTO answer_log(user_id,test_id,chapter_id,topic_id,qid,question,chosen,correct_text,is_correct,misconception,ms,created_at,helped) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)')
    .run(req.user.id, t.id, t.chapter_id, q.t, q.id, q.q, q.opts[choice].t, q.opts[correctIndex].t, correct ? 1 : 0, correct ? null : (q.opts[choice].m || null), now - (t.qts || t.created_at), now, helped);
  let result = null;
  if (i < qs.length - 1) db.prepare('UPDATE tests SET answers=?, qts=? WHERE id=?').run(JSON.stringify(ans), now, t.id);
  else result = finalize(req.user, t, qs, ans, langOf(req));
  res.json(replyFor(t, qs, ans, i, result));
});

/* ---------- профиль, награды, рейтинг, стиль учителя ---------- */
app.get('/api/profile', auth, (req, res) => res.json(gamify.profileFor(req.user)));
app.get('/api/dashboard', auth, (req, res) => { const p=progressFor(req.user.id, req.user.direction, langOf(req), accessFn(req.user)); const pts=gamify.pointsOf(req.user.id); res.json({ level:gamify.levelOf(pts.total), levelProgress:gamify.levelProgress(pts.total), daily:gamify.dailyMission(req.user.id), next:nextChapter(req.user,p,langOf(req)), due:p.dueTopics.slice(0,3).map(x=>({id:x.topicId,name:topicName(x.topicId,langOf(req)),overdueDays:x.overdueDays})) }); });
app.post('/api/style', auth, (req, res) => { // старое имя; то же, что POST /api/tutor
  if (!own(PERSONAS, req.body.style)) return fail(req, res, 400, 'badStyle');
  db.prepare('UPDATE users SET teacher_style=?, tutor_chosen=1 WHERE id=?').run(req.body.style, req.user.id);
  res.json({ ok: true });
});
app.get('/api/leaderboard', auth, (req, res) => res.json(gamify.leaderboardFor(req.user)));
app.post('/api/leaderboard/join', auth, (req, res) => {
  const nick = String(req.body.nickname || '').trim();
  if (!/^[\p{L}\p{N}_]{3,16}$/u.test(nick)) return fail(req, res, 400, 'nickBad');
  const lc = nick.toLowerCase();
  if (db.prepare('SELECT 1 FROM users WHERE nickname_lc=? AND id<>?').get(lc, req.user.id)) return fail(req, res, 409, 'nickTaken');
  db.prepare('UPDATE users SET nickname=?, nickname_lc=?, leaderboard=1 WHERE id=?').run(nick, lc, req.user.id);
  res.json({ ok: true });
});
app.post('/api/leaderboard/leave', auth, (req, res) => {
  db.prepare('UPDATE users SET leaderboard=0, nickname=NULL, nickname_lc=NULL WHERE id=?').run(req.user.id);
  res.json({ ok: true });
});
app.post('/api/admin/nickname/reset', admin, (req, res) => {
  db.prepare('UPDATE users SET leaderboard=0, nickname=NULL, nickname_lc=NULL WHERE nickname_lc=?').run(String(req.body.nickname || '').toLowerCase());
  res.json({ ok: true });
});

/* ---------- «Не понял»: подсказки по лесенке ---------- */
app.post('/api/help', auth, async (req, res) => {
  if (!ai.enabled()) return fail(req, res, 503, 'helpOff');
  if (limited('help:' + req.user.id, 40, 3600e3)) return fail(req, res, 429, 'tooReq');
  const t = db.prepare('SELECT * FROM tests WHERE id=? AND user_id=?').get(String(req.body.testId || ''), req.user.id);
  if (!t) return fail(req, res, 404, 'noTest');
  const qs = JSON.parse(t.qs), ans = JSON.parse(t.answers), i = Number(req.body.index);
  if (!Number.isInteger(i) || i < 0 || i >= qs.length || i > ans.length) return fail(req, res, 400, 'badChoice');
  const turns = db.prepare("SELECT COUNT(*) c FROM help_chat WHERE test_id=? AND q_index=? AND role='assistant'").get(t.id, i).c;
  if (turns >= MAX_HELP) return fail(req, res, 429, 'helpMax');
  const text = String(req.body.text || '').trim().slice(0, 300);
  const q = qs[i], answered = i < ans.length, lang = langOf(req);
  const history = db.prepare('SELECT role, text FROM help_chat WHERE test_id=? AND q_index=? ORDER BY id DESC LIMIT 6').all(t.id, i).reverse();
  try {
    const reply = await ai.help({
      topic: TOPIC[q.t], lang, question: q.q, options: q.opts.map(o => o.t), answered,
      chosen: answered ? q.opts[ans[i]].t : undefined, correct: answered ? q.opts.find(o => o.ok).t : undefined,
      level: turns, history, text, style: req.user.teacher_style
    });
    const now = Date.now(), ins = db.prepare('INSERT INTO help_chat(user_id,test_id,q_index,role,text,created_at) VALUES(?,?,?,?,?,?)');
    db.transaction(() => {
      if (text) ins.run(req.user.id, t.id, i, 'user', text, now);
      ins.run(req.user.id, t.id, i, 'assistant', reply, now);
      // подсказка до ответа: верный ответ засчитается наполовину. Проверяем заново — ученик мог ответить, пока ИИ писал подсказку
      const cur = db.prepare('SELECT helped, answers FROM tests WHERE id=?').get(t.id);
      if (i >= JSON.parse(cur.answers).length) {
        const h = JSON.parse(cur.helped || '[]');
        if (!h.includes(i)) { h.push(i); db.prepare('UPDATE tests SET helped=? WHERE id=?').run(JSON.stringify(h), t.id); }
      }
    })();
    res.json({ reply, left: MAX_HELP - turns - 1, helped: !answered, newBadges: gamify.checkBadges(req.user) });
  } catch (e) { console.error('help:', e.message); fail(req, res, 503, 'genFail'); }
});

/* ---------- «Вопрос неверный»: очередь на проверку ---------- */
app.post('/api/report', auth, (req, res) => {
  if (limited('report:' + req.user.id, 20, 3600e3)) return fail(req, res, 429, 'tooReq');
  const t = db.prepare('SELECT * FROM tests WHERE id=? AND user_id=?').get(String(req.body.testId || ''), req.user.id);
  if (!t) return fail(req, res, 404, 'noTest');
  const qs = JSON.parse(t.qs), ans = JSON.parse(t.answers), i = Number(req.body.index);
  if (!Number.isInteger(i) || i < 0 || i >= qs.length || i > ans.length) return fail(req, res, 400, 'badChoice');
  const q = qs[i];
  db.prepare('INSERT OR IGNORE INTO reports(user_id,qid,topic_id,lang,question,options,reason,created_at) VALUES(?,?,?,?,?,?,?,?)')
    .run(req.user.id, q.id, q.t, langOf(req), q.q, JSON.stringify(q.opts.map(o => ({ t: o.t, ok: o.ok }))), String(req.body.reason || '').trim().slice(0, 300) || null, Date.now());
  // три разных ученика пожаловались: вопрос скрывается до проверки
  const n = db.prepare("SELECT COUNT(DISTINCT user_id) c FROM reports WHERE qid=? AND status='open'").get(q.id).c;
  if (n >= 3) db.prepare('INSERT OR IGNORE INTO blocked_q(qid,reason,created_at) VALUES(?,?,?)').run(q.id, 'auto: 3 reports', Date.now());
  res.json({ ok: true });
});
app.get('/api/admin/reports', admin, (req, res) => {
  const rows = db.prepare(`SELECT r.qid, r.topic_id, r.lang, r.question, r.options, COUNT(*) n, GROUP_CONCAT(r.reason, ' | ') reasons, MAX(r.created_at) last,
      (SELECT 1 FROM blocked_q b WHERE b.qid=r.qid) blocked FROM reports r WHERE r.status='open' GROUP BY r.qid ORDER BY n DESC, last DESC LIMIT 200`).all();
  res.json(rows.map(r => ({ ...r, options: JSON.parse(r.options), blocked: !!r.blocked })));
});
app.post('/api/admin/reports/resolve', admin, (req, res) => {
  const { qid, action } = req.body || {};
  if (!qid || !['hide', 'restore'].includes(action)) return res.status(400).json({ error: 'bad request' });
  db.transaction(() => {
    if (action === 'hide') db.prepare('INSERT OR IGNORE INTO blocked_q(qid,reason,created_at) VALUES(?,?,?)').run(String(qid), 'admin', Date.now());
    else db.prepare('DELETE FROM blocked_q WHERE qid=?').run(String(qid));
    db.prepare("UPDATE reports SET status=? WHERE qid=? AND status='open'").run(action === 'hide' ? 'hidden' : 'dismissed', String(qid));
  })();
  res.json({ ok: true });
});

/* ---------- родители (по коду, только чтение) ---------- */
app.get('/api/parent/:code', (req, res) => {
  if (limited('parent:' + req.ip, 30, 60e3)) return fail(req, res, 429, 'tooReq');
  const code = String(req.params.code).toUpperCase();
  const u = /^[A-Z0-9]{8}$/.test(code) ? db.prepare('SELECT * FROM users WHERE parent_code=?').get(code) : null;
  if (!u) return fail(req, res, 404, 'noCode');
  const lang = langOf(req), p = progressFor(u.id, u.direction, lang, accessFn(u));
  const recent = db.prepare('SELECT chapter_id,correct,total,passed,review,created_at FROM attempts WHERE user_id=? ORDER BY id DESC LIMIT 5').all(u.id)
    .map(a => ({ chapter: own(CH, a.chapter_id) ? chTitle(a.chapter_id, lang) : a.chapter_id, correct: a.correct, total: a.total, passed: !!a.passed, review: !!a.review, at: a.created_at }));
  res.json({
    inactiveDays: u.last_active ? Math.floor((Date.now() - u.last_active) / DAY) : null,
    weakTopics: p.direction ? Object.entries(p.mastery).filter(([id, v]) => v < 60 && own(TOPIC, id) && p.direction.subjects.includes(TOPIC[id].subject))
      .sort((a, b) => a[1] - b[1]).slice(0, 5).map(([id, v]) => ({ subject: subjName(TOPIC[id].subject, lang), topic: topicName(id, lang), pct: v })) : [],
    dueCount: p.dueTopics.length, streak: gamify.streakOf(u.id).current, badges: db.prepare('SELECT COUNT(*) c FROM achievements WHERE user_id=?').get(u.id).c,
    name: u.name, direction: p.direction ? localized(lang).directions.find(d => d.id === p.direction.id).name : null, overall: p.overall, lastActive: u.last_active,
    subjects: p.direction ? p.direction.subjects.map(s => p.subjects[s]) : [], recent
  });
});

/* ---------- оплата ---------- */
const planName = (id, lang) => (localized(lang).plans.find(p => p.id === id) || { name: id }).name;
app.post('/api/orders', auth, (req, res) => {
  const lang = langOf(req), plan = String(req.body.plan || '');
  try { billing.paidPlan(plan); } catch (e) { return fail(req, res, 400, 'badPlan'); }
  if (limited('order:' + req.user.id, 20, 3600e3)) return fail(req, res, 429, 'tooReq');
  const want = String(req.body.method || '');
  const method = want === 'card' && billing.cardEnabled() ? 'card' : want === 'payme' && payme.enabled() ? 'payme'
    : billing.cardEnabled() ? 'card' : payme.enabled() ? 'payme' : 'manual';
  if (method === 'payme') { const o = billing.createOrder(req.user.id, plan, 'payme'); return res.json({ orderId: o.id, method, url: payme.checkoutUrl(o.id, o.amount, lang) }); }
  if (method === 'card') { let o; try { o = billing.createCardOrder(req.user.id, plan); } catch (e) { return fail(req, res, 503, 'tooReq'); } return res.json({ orderId: o.id, method, order: billing.orderView(o), card: billing.cardInfo(), dev: DEV }); }
  const o = billing.createOrder(req.user.id, plan, 'manual');
  res.json({ orderId: o.id, method, manual: true, dev: DEV, message: m(req, 'payOff') });
});
app.get('/api/orders/mine', auth, (req, res) => {
  const rows = db.prepare("SELECT * FROM orders WHERE user_id=? AND (method='card' OR status IN ('paid','refunded')) ORDER BY id DESC LIMIT 10").all(req.user.id);
  res.json({ orders: rows.map(billing.orderView), card: billing.cardEnabled() ? billing.cardInfo() : null });
});
// Чек о переводе: изображение в теле запроса (JPG/PNG/WebP до 6 МБ), комментарий — в ?note=
const sniff = b => !Buffer.isBuffer(b) || b.length < 12 ? null
  : (b[0] === 0xFF && b[1] === 0xD8 && b[2] === 0xFF) ? 'image/jpeg'
  : (b[0] === 0x89 && b.toString('ascii', 1, 4) === 'PNG') ? 'image/png'
  : (b.toString('ascii', 0, 4) === 'RIFF' && b.toString('ascii', 8, 12) === 'WEBP') ? 'image/webp' : null;
const EXT = { 'image/jpeg': 'jpg', 'image/png': 'png', 'image/webp': 'webp' };
app.post('/api/orders/:id/receipt', auth, express.raw({ type: () => true, limit: '6mb' }), (req, res) => {
  if (limited('receipt:' + req.user.id, 10, 3600e3)) return fail(req, res, 429, 'tooReq');
  const o = db.prepare("SELECT * FROM orders WHERE id=? AND user_id=? AND method='card'").get(+req.params.id || 0, req.user.id);
  if (!o) return fail(req, res, 404, 'notFound');
  if (!['new', 'review', 'rejected'].includes(o.status)) return fail(req, res, 409, 'orderState');
  const mime = sniff(req.body);
  if (!mime) return fail(req, res, 400, 'receiptBad');
  fs.mkdirSync(RECEIPTS, { recursive: true });
  const name = `${o.id}-${crypto.randomBytes(6).toString('hex')}.${EXT[mime]}`, file = path.join(RECEIPTS, name);
  fs.writeFileSync(file, req.body);
  billing.attachReceipt(o.id, name, String(req.query.note || '').trim().slice(0, 200));
  if (o.receipt && o.receipt !== name) fs.rm(path.join(RECEIPTS, path.basename(o.receipt)), { force: true }, () => {}); // прежний чек больше не нужен
  const fresh = db.prepare('SELECT * FROM orders WHERE id=?').get(o.id);
  tg.notifyPayment({ order: fresh, user: req.user, planName: planName(fresh.plan, 'ru'), file, mime }).catch(() => {});
  res.json({ order: billing.orderView(fresh) });
});
app.post('/api/dev/pay/:id', auth, (req, res) => {
  if (!DEV) return res.status(404).end();
  const o = db.prepare('SELECT * FROM orders WHERE id=? AND user_id=?').get(+req.params.id, req.user.id);
  if (!o) return fail(req, res, 404, 'notFound');
  billing.markPaid(o.id); res.json({ ok: true });
});
app.post('/payme', payme.handler);
// Админка оплат переводом на карту
app.get('/api/admin/payments', admin, (req, res) => {
  const status = ['review', 'new', 'paid', 'rejected'].includes(req.query.status) ? req.query.status : 'review';
  const rows = db.prepare(`SELECT o.*, u.email, u.name FROM orders o JOIN users u ON u.id=o.user_id
    WHERE o.method IN ('card','manual') AND o.status=? ORDER BY COALESCE(o.receipt_at, o.created_at) DESC LIMIT 100`).all(status);
  res.json(rows.map(o => ({ ...billing.orderView(o), planName: planName(o.plan, 'ru'), email: o.email, name: o.name, note: o.note || '', hasReceipt: !!o.receipt })));
});
app.get('/api/admin/payments/:id/receipt', admin, (req, res) => {
  const o = db.prepare('SELECT receipt FROM orders WHERE id=?').get(+req.params.id || 0);
  if (!o || !o.receipt) return res.status(404).json({ error: 'Чека нет' });
  res.set('Cache-Control', 'no-store');
  res.sendFile(path.join(RECEIPTS, path.basename(o.receipt)));
});
app.post('/api/admin/payments/:id/approve', admin, (req, res) => {
  const o = billing.approve(+req.params.id || 0);
  if (!o) return res.status(409).json({ error: 'Заказ не найден или уже обработан' });
  res.json({ ok: true, order: billing.orderView(o) });
});
app.post('/api/admin/payments/:id/reject', admin, (req, res) => {
  const o = billing.reject(+req.params.id || 0, String((req.body && req.body.reason) || 'nf'));
  if (!o) return res.status(409).json({ error: 'Заказ не найден или уже обработан' });
  res.json({ ok: true, order: billing.orderView(o) });
});
app.post('/api/admin/activate', admin, (req, res) => {
  const u = db.prepare('SELECT * FROM users WHERE lower(email)=?').get(String(req.body.email || '').trim().toLowerCase());
  if (!u) return res.status(404).json({ error: 'Пользователь не найден' });
  try { billing.activate(u.id, String(req.body.plan)); res.json({ ok: true }); } catch (e) { res.status(400).json({ error: e.message }); }
});
app.post('/api/admin/backup', admin, async (req, res) => {
  try { res.json({ ok: true, file: path.basename(await backup.backupNow()) }); } catch (e) { res.status(500).json({ error: e.message }); }
});

/* ---------- страницы ---------- */
app.use(express.static(path.join(__dirname, 'public')));
app.get('/p/:code', (req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));
app.use('/api', (req, res) => fail(req, res, 404, 'notFound'));
app.use((err, req, res, next) => {
  if (req.path === '/payme' && err.type === 'entity.parse.failed') return payme.parseError(res);
  if (err.type === 'entity.too.large') return fail(req, res, 413, req.path.includes('/receipt') ? 'receiptBig' : 'tooReq');
  if (err.type === 'entity.parse.failed') return res.status(400).json({ error: M[langOf(req)].server });
  console.error(err);
  res.status(500).json({ error: M[langOf(req)].server });
});

setInterval(() => db.prepare('DELETE FROM sessions WHERE expires<?').run(Date.now()), 6 * 3600e3).unref();
app.listen(PORT, HOST, () => {
  console.log(`Ustoz AI: http://${HOST === '0.0.0.0' ? 'localhost' : HOST}:${PORT}${DEV ? '  [DEV_MODE: тестовый вход включён]' : ''}`);
  if (!GID && !DEV) console.warn('Внимание: GOOGLE_CLIENT_ID не задан, войти будет нельзя.');
  if (!billing.cardEnabled() && !payme.enabled()) console.warn('Внимание: оплата не настроена (CARD_NUMBER или Payme). Подписку можно выдать вручную через /api/admin/activate.');
  tg.start({ approve: id => billing.approve(id), reject: (id, reason) => billing.reject(id, reason) });
  backup.schedule();
});
