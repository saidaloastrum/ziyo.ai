// Заглушка Anthropic API для автотестов и локальной проверки без ключа.
// Запуск отдельно: node test/mock-anthropic.js 4555, затем ANTHROPIC_BASE_URL=http://127.0.0.1:4555 ANTHROPIC_API_KEY=test
// Отвечает правдоподобно на все запросы проекта: уроки, мини-уроки, вопросы (+ их проверку), подсказки и чат (потоком).
const http = require('http');

const log = [];
const delay = { help: 0, stream: 0 }; // искусственные задержки для проверки гонок (POST /__delay)
const reply = (res, status, obj) => { res.writeHead(status, { 'content-type': 'application/json' }); res.end(JSON.stringify(obj)); };
const textMsg = text => ({ id: 'msg_mock', type: 'message', role: 'assistant', content: [{ type: 'text', text }], stop_reason: 'end_turn' });

// Вопросы-заглушки: «Сколько будет N + N?», верный ответ 2N стоит на разных позициях
function mockQuestions(topic) {
  return Array.from({ length: 8 }, (_, i) => {
    const n = i + 3, right = String(2 * n), wrong = [String(2 * n + 1), String(2 * n - 1), String(2 * n + 2)];
    const a = i % 4, o = [...wrong]; o.splice(a, 0, right);
    return { q: `[${topic}] Сколько будет ${n} + ${n}?`, o, a, e: `${n} + ${n} = ${2 * n}.`, m: o.map((x, j) => j === a ? '' : 'Ошибка в сложении') };
  });
}
function solve(list) { // «решает» вопросы заглушки: ищет вариант, равный 2N
  return list.map(x => { const n = +(String(x.q).match(/(\d+) \+ \1/) || [0, 0])[1]; return x.o.indexOf(String(2 * n)); });
}

function nonStream(body) {
  const sys = String(body.system || ''), user = String((body.messages[body.messages.length - 1] || {}).content || '');
  if (sys.startsWith('Ты внимательно решаешь тесты')) {
    const list = JSON.parse(user.slice(user.indexOf('[')));
    return textMsg(list.map((x, i) => `${i + 1}) складываем числа`).join('\n') + '\n' + JSON.stringify(solve(list)));
  }
  if (sys.startsWith('Ты терпеливый ИИ-репетитор')) return textMsg(/Ученик ещё не ответил/.test(user) ? 'Подсказка: вспомни правило и посмотри на условие внимательно.' : 'Полный разбор: решаем по шагам и проверяем ответ.');
  if (/Составь 8 тестовых вопросов/.test(user)) { const topic = (user.match(/Тема: «([^»]+)»/) || [0, 'тема'])[1]; return textMsg(JSON.stringify(mockQuestions(topic))); }
  if (/Напиши урок/.test(user)) return textMsg(JSON.stringify({ intro: 'Это урок-заглушка.\n\nВторой абзац урока.', example: 'Пример: 2 + 2 = 4.' }));
  if (/Способ объяснения/.test(user)) return textMsg(JSON.stringify({ text: 'Персональный разбор твоих ошибок (заглушка).', example: 'Разберём на примере.' }));
  if (/Напиши мини-урок/.test(user)) return textMsg(JSON.stringify({ text: 'Мини-урок (заглушка).', example: 'Короткий пример.' }));
  return textMsg('Ответ заглушки.');
}

function streamReply(res, body) {
  const user = String((body.messages[body.messages.length - 1] || {}).content || '');
  if (/HTTP500/.test(user)) return reply(res, 500, { type: 'error', error: { type: 'api_error', message: 'mock failure' } });
  res.writeHead(200, { 'content-type': 'text/event-stream', 'cache-control': 'no-cache' });
  const ev = (type, data) => res.write(`event: ${type}\ndata: ${JSON.stringify({ type, ...data })}\n\n`);
  const text = /Отвечай на узбекском/.test(String(body.system)) ? 'Yaxshi savol! Keling, qadamma-qadam ko\'rib chiqamiz.\n\n1. Shartni o\'qiymiz.\n2. Qoidani qo\'llaymiz.' :
    'Хороший вопрос! Разберём по шагам.\n\n1. Читаем условие.\n2. Применяем правило: **главное** — не спешить.\n— Проверяем ответ подстановкой.';
  const parts = text.match(/.{1,12}/gs);
  ev('message_start', { message: { id: 'msg_mock', role: 'assistant', content: [] } });
  ev('content_block_start', { index: 0, content_block: { type: 'text', text: '' } });
  let i = 0;
  const tick = () => {
    if (/ОШИБКА_ПОТОКА/.test(user) && i === 3) { ev('error', { error: { type: 'overloaded_error', message: 'Overloaded' } }); return res.end(); }
    if (i < parts.length) { ev('content_block_delta', { index: 0, delta: { type: 'text_delta', text: parts[i++] } }); return setTimeout(tick, 15); }
    ev('content_block_stop', { index: 0 }); ev('message_delta', { delta: { stop_reason: 'end_turn' } }); ev('message_stop', {}); res.end();
  };
  tick();
}

function start(port = 0) {
  const srv = http.createServer((req, res) => {
    if (req.method === 'GET' && req.url === '/__log') return reply(res, 200, log);
    if (req.method === 'POST' && req.url === '/__reset') { log.length = 0; delay.help = delay.stream = 0; return reply(res, 200, { ok: true }); }
    if (req.method === 'POST' && req.url === '/__delay') { let b = ''; req.on('data', c => { b += c; }); req.on('end', () => { Object.assign(delay, JSON.parse(b || '{}')); reply(res, 200, delay); }); return; }
    if (req.method !== 'POST' || req.url !== '/v1/messages') return reply(res, 404, {});
    let raw = '';
    req.on('data', c => { raw += c; });
    req.on('end', () => {
      const body = JSON.parse(raw); log.push({ headers: { key: req.headers['x-api-key'] }, body });
      if (body.stream) return setTimeout(() => streamReply(res, body), delay.stream);
      const isHelp = String(body.system || '').startsWith('Ты терпеливый ИИ-репетитор');
      setTimeout(() => reply(res, 200, nonStream(body)), isHelp ? delay.help : 0);
    });
  });
  return new Promise(r => srv.listen(port, '127.0.0.1', () => r(srv)));
}
module.exports = { start, mockQuestions };
if (require.main === module) start(+process.argv[2] || 4555).then(s => console.log('mock Anthropic on http://127.0.0.1:' + s.address().port));
