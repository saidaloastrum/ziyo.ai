// Автотесты API: npm test. Поднимают сервер на временной базе и заглушку Anthropic (без ключа и без интернета).
const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const { spawn } = require('child_process');
const crypto = require('crypto');
const fs = require('fs');
const os = require('os');
const path = require('path');
const Database = require('better-sqlite3');
const mock = require('./mock-anthropic');
const seed = require('../lib/seed');

const ROOT = path.join(__dirname, '..');
const ADMIN = 'test-admin-token-1234567890';
const PNG = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=', 'base64');
let srv, mockSrv, BASE, DB, db, mockURL;

const qid = (lang, topic, q) => (lang === 'uz' ? 'uz:' : '') + topic + ':' + crypto.createHash('sha1').update(q.q + '\u0001' + q.o.join('\u0001')).digest('hex').slice(0, 10);
const KEY = new Map();
for (const qs of Object.values(seed.ru.questions)) for (const q of qs) KEY.set(q.q, q.o[q.a]);
function correctIdx(q, options) {
  if (KEY.has(q)) return options.indexOf(KEY.get(q));
  const n = +(q.match(/(\d+) \+ \1/) || [0, NaN])[1]; // вопросы заглушки: «Сколько будет N + N?»
  return options.indexOf(String(2 * n));
}

function startServer(env, dbPath) {
  const port = 4100 + Math.floor(Math.random() * 800);
  const child = spawn(process.execPath, ['server.js'], {
    cwd: ROOT, stdio: ['ignore', 'pipe', 'pipe'],
    env: { ...process.env, PORT: String(port), HOST: '127.0.0.1', NODE_ENV: 'test', DB_PATH: dbPath, BACKUP_HOURS: '0', TELEGRAM_BOT_TOKEN: '', PAYME_MERCHANT_ID: '', PAYME_KEY: '', GOOGLE_CLIENT_ID: '', ...env }
  });
  return new Promise((resolve, reject) => {
    let out = '';
    child.stdout.on('data', d => { out += d; if (out.includes('Ustoz AI:')) resolve({ child, base: `http://127.0.0.1:${port}` }); });
    child.stderr.on('data', d => { out += d; });
    child.on('exit', code => reject(Object.assign(new Error('server exited ' + code + '\n' + out), { code, out })));
  });
}

before(async () => {
  mockSrv = await mock.start(0);
  mockURL = `http://127.0.0.1:${mockSrv.address().port}`;
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'ustoz-test-'));
  DB = path.join(dir, 'u.db');
  // база «старой версии»: скрытый вопрос с позиционным ID, который должна переписать миграция
  const pre = new Database(DB);
  pre.exec('CREATE TABLE blocked_q(qid TEXT PRIMARY KEY, reason TEXT, created_at INTEGER NOT NULL)');
  pre.prepare('INSERT INTO blocked_q VALUES(?,?,?)').run('uz:q2-0', 'old', 1);
  pre.close();
  const s = await startServer({ DEV_MODE: '1', ADMIN_TOKEN: ADMIN, ANTHROPIC_API_KEY: 'test', ANTHROPIC_BASE_URL: mockURL, CARD_NUMBER: '8600 1234 5678 9012', CARD_HOLDER: 'TEST HOLDER', CHAT_FREE_DAILY: '3' }, DB);
  srv = s.child; BASE = s.base;
  db = new Database(DB);
});
after(() => { if (srv) srv.kill(); if (mockSrv) mockSrv.close(); if (db) db.close(); });

async function login(email, name = 'Ученик Тестов') {
  const r = await fetch(BASE + '/api/auth/dev', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ email, name }) });
  assert.equal(r.status, 200);
  return { sid: r.headers.get('set-cookie').match(/sid=([^;]+)/)[1], email };
}
async function api(u, p, body, extra = {}) {
  const r = await fetch(BASE + p, {
    method: body !== undefined ? 'POST' : 'GET',
    headers: { 'content-type': 'application/json', cookie: u ? 'sid=' + u.sid : '', 'x-lang': 'ru', ...extra },
    body: body !== undefined ? JSON.stringify(body) : undefined
  });
  let j = null; try { j = await r.json(); } catch (e) { /* не JSON */ }
  return { status: r.status, j, headers: r.headers };
}
const adminApi = (p, body) => api(null, p, body, { 'x-admin-token': ADMIN });
const uid = email => db.prepare('SELECT id FROM users WHERE email=?').get(email).id;
async function newUser(email, direction = 'eco') { const u = await login(email); await api(u, '/api/direction', { direction }); return u; }
async function subscribe(u) {
  const o = await api(u, '/api/orders', { plan: 'std', method: 'card' });
  const r = await api(u, '/api/dev/pay/' + o.j.orderId, {});
  assert.equal(r.status, 200);
}
// Проходит тест целиком: mode 'right' | 'wrong'; helpAt — номера вопросов, где до ответа взять подсказку
async function runTest(u, startBody, mode = 'right', helpAt = []) {
  const s = await api(u, '/api/test/start', startBody);
  assert.equal(s.status, 200, JSON.stringify(s.j));
  let T = s.j; const seen = [T.q];
  for (;;) {
    if (helpAt.includes(T.index)) { const h = await api(u, '/api/help', { testId: T.testId, index: T.index }); assert.equal(h.status, 200); }
    const ci = correctIdx(T.q, T.options);
    assert.ok(ci >= 0, 'нет ключа для: ' + T.q);
    const a = await api(u, '/api/test/answer', { testId: T.testId, index: T.index, choice: mode === 'right' ? ci : (ci + 1) % 4 });
    assert.equal(a.status, 200, JSON.stringify(a.j));
    if (a.j.result) return { res: a.j.result, seen, testId: T.testId };
    T = { ...T, index: a.j.next.index, q: a.j.next.q, options: a.j.next.options };
    seen.push(T.q);
  }
}

test('заголовки безопасности на месте', async () => {
  const r = await fetch(BASE + '/api/config');
  assert.equal(r.headers.get('x-frame-options'), 'DENY');
  assert.match(r.headers.get('content-security-policy'), /frame-ancestors 'none'/);
  assert.equal(r.headers.get('x-powered-by'), null);
});

test('битая cookie не роняет сервер, ключи вида __proto__ не проходят', async () => {
  const r = await fetch(BASE + '/api/me', { headers: { cookie: 'sid=%E0%A4%A' } });
  assert.equal(r.status, 401);
  const u = await newUser('proto@test.uz');
  assert.equal((await api(u, '/api/chapter/__proto__')).status, 404);
  assert.equal((await api(u, '/api/chapter/constructor')).status, 404);
  assert.equal((await api(u, '/api/mini?topics=constructor,toString')).status, 404);
  assert.equal((await api(u, '/api/test/start', { chapterId: 'hasOwnProperty' })).status, 404);
});

test('миграция переводит старые позиционные ID вопросов в новые', () => {
  const want = qid('uz', 'q2', seed.uz.questions.q2[0]);
  assert.ok(db.prepare('SELECT 1 FROM blocked_q WHERE qid=?').get(want));
  assert.equal(db.prepare('SELECT 1 FROM blocked_q WHERE qid=?').get('uz:q2-0'), undefined);
});

test('очки: «провалить нарочно и пройти снова» больше ничего не даёт', async () => {
  const u = await newUser('farmer@test.uz');
  const first = await runTest(u, { chapterId: 'math-1' }, 'right');
  assert.ok(first.res.points > 0);
  // раньше каждый цикл давал ~54 очка; теперь только за превышение лучшего уровня: 6 → 1 → 0
  const gained = [];
  for (let i = 0; i < 3; i++) {
    const f = await runTest(u, { chapterId: 'math-1' }, 'wrong');
    const p = await runTest(u, { chapterId: 'math-1' }, 'right');
    assert.equal(f.res.points, 0);
    gained.push(p.res.points);
  }
  assert.ok(gained.reduce((a, b) => a + b, 0) <= 10, 'циклы дали слишком много очков: ' + gained);
  assert.equal(gained[2], 0, 'накрутка должна сходиться к нулю');
});

test('повторная отправка ответа возвращает тот же результат, чужой номер вопроса — 409', async () => {
  const u = await newUser('retry@test.uz');
  const s = (await api(u, '/api/test/start', { chapterId: 'math-1' })).j;
  const ci = correctIdx(s.q, s.options);
  const a1 = await api(u, '/api/test/answer', { testId: s.testId, index: 0, choice: ci });
  const a2 = await api(u, '/api/test/answer', { testId: s.testId, index: 0, choice: ci });
  assert.equal(a1.status, 200); assert.deepEqual(a2.j, a1.j);
  assert.equal(a2.j.correct, true);
  const other = await api(u, '/api/test/answer', { testId: s.testId, index: 0, choice: (ci + 1) % 4 });
  assert.equal(other.status, 409); assert.equal(other.j.sync.index, 1);
  const skip = await api(u, '/api/test/answer', { testId: s.testId, index: 3, choice: 0 });
  assert.equal(skip.status, 409);
  // доходим до конца и повторяем последний ответ: приходит тот же итог
  let T = { testId: s.testId, index: 1, q: a1.j.next.q, options: a1.j.next.options }, last;
  for (;;) {
    const body = { testId: T.testId, index: T.index, choice: correctIdx(T.q, T.options) };
    const a = await api(u, '/api/test/answer', body);
    if (a.j.result) { last = { body, j: a.j }; break; }
    T = { ...T, index: a.j.next.index, q: a.j.next.q, options: a.j.next.options };
  }
  const again = await api(u, '/api/test/answer', last.body);
  assert.equal(again.status, 200); assert.deepEqual(again.j, last.j);
  const after = await api(u, '/api/test/answer', { testId: s.testId, index: 4, choice: 0 });
  assert.equal(after.status, 404);
});

test('скрытые вопросы не показываются, тема пополняется в фоне', async () => {
  const hidden = seed.ru.questions.p1.slice(0, 2);
  for (const q of hidden) assert.equal((await adminApi('/api/admin/reports/resolve', { qid: qid('ru', 'p1', q), action: 'hide' })).status, 200);
  const u = await newUser('hidden@test.uz');
  const texts = new Set(hidden.map(q => q.q));
  for (let i = 0; i < 6; i++) {
    const { seen } = await runTest(u, { chapterId: 'math-1' }, 'right');
    assert.ok(!seen.some(q => texts.has(q)), 'скрытый вопрос попал в тест');
  }
  const log = await (await fetch(mockURL + '/__log')).json();
  assert.ok(log.some(x => /Составь 8 тестовых вопросов/.test(x.body.messages[0].content) && /Тема: «Проценты»/.test(x.body.messages[0].content)), 'не запущено пополнение темы');
});

test('мини-уроки платных глав недоступны без подписки', async () => {
  const free = await newUser('free-mini@test.uz');
  assert.equal((await api(free, '/api/chapter/math-4')).status, 402);
  assert.equal((await api(free, '/api/mini?topics=math-4-a')).status, 404);
  assert.equal((await api(free, '/api/mini?topics=p1')).status, 200);
  const paid = await newUser('paid-mini@test.uz');
  await subscribe(paid);
  const r = await api(paid, '/api/mini?topics=math-4-a');
  assert.equal(r.status, 200); assert.equal(r.j[0].id, 'math-4-a');
});

test('после окончания подписки «пора повторить» считает только доступные темы', async () => {
  const u = await newUser('expired@test.uz');
  await subscribe(u);
  await runTest(u, { chapterId: 'math-4' }, 'right');
  db.prepare('UPDATE users SET plan_until=? WHERE id=?').run(Date.now() - 864e5, uid('expired@test.uz'));
  db.prepare('UPDATE topic_review SET due_at=? WHERE user_id=?').run(Date.now() - 5 * 864e5, uid('expired@test.uz'));
  const p = await api(u, '/api/progress');
  assert.equal(p.j.dueCount, 0); assert.equal(p.j.lockedDue, 2);
  assert.equal((await api(u, '/api/test/start', { review: true })).status, 400);
});

test('ответ после подсказки засчитывается наполовину и не идёт в зачёт главы', async () => {
  const u = await newUser('helped@test.uz');
  const one = await runTest(u, { chapterId: 'math-2' }, 'right', [0]);
  assert.equal(one.res.right, 4); assert.equal(one.res.solo, 3); assert.equal(one.res.assisted, 1); assert.equal(one.res.passed, true);
  const two = await runTest(u, { chapterId: 'math-2' }, 'right', [0, 1]);
  assert.equal(two.res.solo, 2); assert.equal(two.res.passed, false);
});

test('оплата переводом на карту: уникальная сумма, чек, отклонение, подтверждение', async () => {
  const a = await newUser('pay-a@test.uz'), b = await newUser('pay-b@test.uz');
  const oa = (await api(a, '/api/orders', { plan: 'std' })).j, ob = (await api(b, '/api/orders', { plan: 'std' })).j;
  assert.equal(oa.method, 'card'); assert.equal(oa.card.number, '8600 1234 5678 9012');
  assert.ok(oa.order.amount > 49000 && oa.order.amount < 49100);
  assert.notEqual(oa.order.amount, ob.order.amount, 'суммы разных учеников должны отличаться');
  assert.equal((await api(a, '/api/orders', { plan: 'std' })).j.orderId, oa.orderId, 'повторное нажатие не плодит заказы');
  const up = (u, id, body, type = 'image/png') => fetch(`${BASE}/api/orders/${id}/receipt?note=${encodeURIComponent('карта *1234')}`, { method: 'POST', headers: { 'content-type': type, cookie: 'sid=' + u.sid }, body });
  assert.equal((await up(a, oa.orderId, Buffer.from('not an image at all'))).status, 400);
  assert.equal((await up(b, oa.orderId, PNG)).status, 404, 'чужой заказ');
  const ok = await up(a, oa.orderId, PNG);
  assert.equal(ok.status, 200); assert.equal((await ok.json()).order.status, 'review');
  const list = (await adminApi('/api/admin/payments?status=review')).j;
  const row = list.find(x => x.id === oa.orderId);
  assert.ok(row && row.hasReceipt && row.note === 'карта *1234');
  const img = await fetch(`${BASE}/api/admin/payments/${oa.orderId}/receipt`, { headers: { 'x-admin-token': ADMIN } });
  assert.equal(img.status, 200); assert.equal(img.headers.get('content-type'), 'image/png');
  assert.equal((await fetch(`${BASE}/api/admin/payments/${oa.orderId}/receipt`)).status, 403);
  assert.equal((await adminApi(`/api/admin/payments/${oa.orderId}/reject`, { reason: 'amt' })).status, 200);
  const mine = (await api(a, '/api/orders/mine')).j.orders.find(x => x.id === oa.orderId);
  assert.equal(mine.status, 'rejected'); assert.equal(mine.rejectReason, 'amt');
  assert.equal((await up(a, oa.orderId, PNG)).status, 200, 'после отклонения можно загрузить чек заново');
  assert.equal((await adminApi(`/api/admin/payments/${oa.orderId}/approve`, {})).status, 200);
  assert.equal((await api(a, '/api/me')).j.user.active, true);
  assert.equal((await adminApi(`/api/admin/payments/${oa.orderId}/approve`, {})).status, 409, 'повторное подтверждение не продлевает подписку');
  assert.equal((await up(a, oa.orderId, PNG)).status, 409, 'оплаченный заказ закрыт');
});

test('чат: ответ приходит потоком, история сохраняется, дневной лимит работает', async () => {
  const u = await login('chat@test.uz', 'Сардор Каримов');
  await api(u, '/api/direction', { direction: 'it' });
  await api(u, '/api/tutor', { persona: 'mentor' });
  await fetch(mockURL + '/__reset', { method: 'POST' });
  const say = text => fetch(BASE + '/api/chat', { method: 'POST', headers: { 'content-type': 'application/json', cookie: 'sid=' + u.sid, 'x-lang': 'ru' }, body: JSON.stringify({ text, chapterId: 'math-2' }) });
  const r1 = await say('Как найти дискриминант?');
  assert.equal(r1.status, 200); assert.match(r1.headers.get('content-type'), /text\/plain/);
  const t1 = await r1.text();
  assert.match(t1, /Хороший вопрос/);
  const sent = (await (await fetch(mockURL + '/__log')).json()).find(x => x.body.stream);
  assert.match(sent.body.system, /Азиза/);
  assert.match(sent.body.system, /Линейные уравнения и неравенства/, 'контекст урока передан');
  assert.ok(!/Сардор|Каримов|chat@test\.uz/.test(JSON.stringify(sent.body)), 'имя и почта ученика не уходят в ИИ');
  const r2 = await say('HTTP500');
  assert.equal(r2.status, 503);
  const t3 = await (await say('ОШИБКА_ПОТОКА')).text();
  assert.ok(t3.includes('\u001E'), 'обрыв потока помечен');
  assert.equal((await say('Ещё вопрос')).status, 200);
  const r5 = await say('И ещё один');
  assert.equal(r5.status, 429);
  const hist = (await api(u, '/api/chat')).j;
  assert.equal(hist.messages.filter(x => x.role === 'user').length, 3);
  assert.equal(hist.limit.used, 3); assert.equal(hist.limit.limit, 3);
});

test('наставник: выбор, сводка для приветствия и «что я помню»', async () => {
  const u = await newUser('tutor@test.uz', 'it');
  assert.equal((await api(u, '/api/tutor', { persona: 'nobody' })).status, 400);
  assert.equal((await api(u, '/api/tutor', { persona: 'professor' })).status, 200);
  await runTest(u, { chapterId: 'math-1' }, 'wrong');
  const t = (await api(u, '/api/tutor')).j;
  assert.equal(t.persona, 'professor'); assert.equal(t.chosen, true);
  assert.equal(t.brief.firstName, 'Ученик');
  assert.ok(t.brief.weakTopic && t.brief.weakTopic.chapterId === 'math-1');
  assert.ok(t.memory.mistakes >= 4 && t.memory.tests === 1);
  const cat = (await api(u, '/api/catalog')).j;
  assert.equal(cat.personas.length, 3);
});

test('сумма заказа на карту остаётся занятой, пока чек на проверке, даже через неделю', async () => {
  const a = await newUser('amt-a@test.uz');
  const oa = (await api(a, '/api/orders', { plan: 'year' })).j;
  const up = await fetch(`${BASE}/api/orders/${oa.orderId}/receipt`, { method: 'POST', headers: { 'content-type': 'image/png', cookie: 'sid=' + a.sid }, body: PNG });
  assert.equal(up.status, 200);
  db.prepare('UPDATE orders SET created_at=? WHERE id=?').run(Date.now() - 8 * 864e5, oa.orderId);
  assert.equal((await api(a, '/api/orders', { plan: 'year' })).j.orderId, oa.orderId, 'ученик с чеком на проверке получает тот же заказ');
  const amounts = new Set();
  for (let i = 0; i < 25; i++) { const u = await newUser(`amt-${i}@test.uz`); amounts.add((await api(u, '/api/orders', { plan: 'year' })).j.order.amount); }
  assert.ok(!amounts.has(oa.order.amount), 'сумма заказа на проверке выдана другому');
  assert.equal(amounts.size, 25, 'суммы открытых заказов должны быть разными');
});

test('ответ, отправленный пока пишется подсказка, засчитывается как самостоятельный', async () => {
  const u = await newUser('race@test.uz');
  await fetch(mockURL + '/__delay', { method: 'POST', body: JSON.stringify({ help: 700 }) });
  const s = (await api(u, '/api/test/start', { chapterId: 'math-2' })).j;
  const helpP = api(u, '/api/help', { testId: s.testId, index: 0 });
  await new Promise(r => setTimeout(r, 150));
  const a = await api(u, '/api/test/answer', { testId: s.testId, index: 0, choice: correctIdx(s.q, s.options) });
  assert.equal(a.j.helped, false);
  assert.equal((await helpP).status, 200);
  await fetch(mockURL + '/__reset', { method: 'POST' });
  let T = { testId: s.testId, index: 1, q: a.j.next.q, options: a.j.next.options }, res;
  for (;;) { const r = await api(u, '/api/test/answer', { testId: T.testId, index: T.index, choice: correctIdx(T.q, T.options) }); if (r.j.result) { res = r.j.result; break; } T = { ...T, index: r.j.next.index, q: r.j.next.q, options: r.j.next.options }; }
  assert.equal(res.assisted, 0); assert.equal(res.solo, 4);
});

test('последний ответ потерялся, а повтор пришёл с другим вариантом: сервер отдаёт сохранённый итог', async () => {
  const u = await newUser('lost-final@test.uz');
  const { testId } = await runTest(u, { chapterId: 'math-1' }, 'right');
  const r = await api(u, '/api/test/answer', { testId, index: 3, choice: 9 });
  assert.equal(r.status, 409); assert.equal(r.j.sync.done, true); assert.equal(r.j.sync.result.total, 4);
});

test('способ объяснения меняется при каждой неудаче', async () => {
  const u = await newUser('methods@test.uz');
  const seen = [];
  for (let i = 0; i < 6; i++) {
    await runTest(u, { chapterId: 'math-2' }, 'wrong');
    const m = await api(u, '/api/mini?topics=l1');
    assert.equal(m.status, 200); seen.push(m.j[0].method);
  }
  for (let i = 1; i < seen.length; i++) assert.notEqual(seen[i], seen[i - 1], 'повтор способа: ' + seen.join(','));
});

test('чат: ученик ушёл до первого слова — вопрос не засчитывается и не сохраняется', async () => {
  const u = await login('chat-gone@test.uz');
  await api(u, '/api/direction', { direction: 'it' });
  await fetch(mockURL + '/__delay', { method: 'POST', body: JSON.stringify({ stream: 800 }) });
  const ctl = new AbortController();
  const p = fetch(BASE + '/api/chat', { method: 'POST', signal: ctl.signal, headers: { 'content-type': 'application/json', cookie: 'sid=' + u.sid }, body: JSON.stringify({ text: 'Вопрос' }) }).catch(() => null);
  setTimeout(() => ctl.abort(), 150);
  await p;
  await new Promise(r => setTimeout(r, 1500));
  await fetch(mockURL + '/__reset', { method: 'POST' });
  const h = (await api(u, '/api/chat')).j;
  assert.equal(h.messages.length, 0); assert.equal(h.limit.used, 0);
});

test('резервная копия содержит данные', async () => {
  const r = await adminApi('/api/admin/backup', {});
  assert.equal(r.status, 200);
  const copy = new Database(path.join(path.dirname(DB), 'backups', r.j.file), { readonly: true });
  assert.ok(copy.prepare('SELECT COUNT(*) c FROM users').get().c > 5);
  copy.close();
});

test('удаление аккаунта обезличивает ученика и сохраняет платежи', async () => {
  const u = await newUser('delete-me@test.uz');
  await subscribe(u);
  const id = uid('delete-me@test.uz');
  assert.equal((await api(u, '/api/account/delete', {})).status, 400);
  assert.equal((await api(u, '/api/account/delete', { confirm: true })).status, 200);
  assert.equal(db.prepare('SELECT email FROM users WHERE id=?').get(id).email, null);
  assert.ok(db.prepare('SELECT COUNT(*) c FROM orders WHERE user_id=?').get(id).c > 0);
  assert.equal((await api(u, '/api/me')).status, 401);
});

test('Payme: битый JSON даёт ошибку -32700 с кодом HTTP 200', async () => {
  const r = await fetch(BASE + '/payme', { method: 'POST', headers: { 'content-type': 'application/json' }, body: '{"id":1,"method":' });
  assert.equal(r.status, 200); assert.equal((await r.json()).error.code, -32700);
});

test('Payme: ключ из ChangePassword действует, пока PAYME_KEY в .env не поменяли', async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'ustoz-payme-'));
  const dbPath = path.join(dir, 'p.db');
  const rpc = (base, key, method, params = {}) => fetch(base + '/payme', { method: 'POST', headers: { 'content-type': 'application/json', authorization: 'Basic ' + Buffer.from('Paycom:' + key).toString('base64') }, body: JSON.stringify({ id: 1, method, params }) }).then(r => r.json());
  const authOk = j => !(j.error && j.error.code === -32504);
  let s = await startServer({ PAYME_MERCHANT_ID: 'm1', PAYME_KEY: 'sandbox-key-1' }, dbPath);
  try {
    assert.ok(authOk(await rpc(s.base, 'sandbox-key-1', 'ChangePassword', { password: 'changed-key-2' })));
    assert.ok(authOk(await rpc(s.base, 'changed-key-2', 'CheckTransaction', { id: 'x' })), 'новый ключ из кабинета принят');
    assert.ok(!authOk(await rpc(s.base, 'sandbox-key-1', 'CheckTransaction', { id: 'x' })), 'старый ключ больше не принимается');
  } finally { s.child.kill(); }
  await new Promise(r => setTimeout(r, 200));
  s = await startServer({ PAYME_MERCHANT_ID: 'm1', PAYME_KEY: 'production-key-3' }, dbPath);
  try {
    assert.ok(authOk(await rpc(s.base, 'production-key-3', 'CheckTransaction', { id: 'x' })), 'новый ключ из .env действует');
    assert.ok(!authOk(await rpc(s.base, 'changed-key-2', 'CheckTransaction', { id: 'x' })));
  } finally { s.child.kill(); }
});

test('подбор токена админки ограничен', async () => {
  for (let i = 0; i < 10; i++) await fetch(BASE + '/api/admin/reports', { headers: { 'x-admin-token': 'wrong' + i } });
  const r = await fetch(BASE + '/api/admin/reports', { headers: { 'x-admin-token': 'wrong-again' } });
  assert.equal(r.status, 429);
});

test('DEV_MODE=1 вместе с NODE_ENV=production не запускается', async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'ustoz-dev-'));
  await assert.rejects(startServer({ DEV_MODE: '1', NODE_ENV: 'production' }, path.join(dir, 'x.db')), e => e.code === 1);
});
