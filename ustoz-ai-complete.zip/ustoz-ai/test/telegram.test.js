// Проверка Telegram-сценария владельца: чек приходит фото с кнопками, «Подтвердить»/«Отклонить» работают из чата.
// Вместо api.telegram.org — локальная заглушка (TELEGRAM_API_BASE).
const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const http = require('http');
const { spawn } = require('child_process');
const fs = require('fs');
const os = require('os');
const path = require('path');

const ADMIN_CHAT = '777000';
const PNG = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=', 'base64');
let tg, child, BASE;
const calls = [], queue = [];
let nextUpdate = 1;

function startTelegramMock() {
  return new Promise(resolve => {
    const srv = http.createServer((req, res) => {
      const method = req.url.split('/').pop();
      let raw = Buffer.alloc(0);
      req.on('data', c => { raw = Buffer.concat([raw, c]); });
      req.on('end', () => {
        const isJson = String(req.headers['content-type'] || '').includes('json');
        const body = isJson && raw.length ? JSON.parse(raw) : { multipart: raw.toString('latin1') };
        const ok = result => { res.writeHead(200, { 'content-type': 'application/json' }); res.end(JSON.stringify({ ok: true, result })); };
        if (method === 'getMe') return ok({ id: 1, is_bot: true, username: 'ustoz_test_bot' });
        if (method === 'getUpdates') {
          const send = () => ok(queue.splice(0).map(u => ({ update_id: nextUpdate++, ...u })));
          return queue.length ? send() : setTimeout(send, 150);
        }
        calls.push({ method, body });
        ok(method === 'sendPhoto' || method === 'sendMessage' ? { message_id: 42 } : true);
      });
    });
    srv.listen(0, '127.0.0.1', () => resolve(srv));
  });
}
const waitFor = async (pred, ms = 4000) => {
  const t0 = Date.now();
  for (;;) { const hit = calls.find(pred); if (hit) return hit; if (Date.now() - t0 > ms) throw new Error('не дождались вызова Telegram'); await new Promise(r => setTimeout(r, 50)); }
};

before(async () => {
  tg = await startTelegramMock();
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'ustoz-tg-'));
  const port = 5100 + Math.floor(Math.random() * 500);
  BASE = `http://127.0.0.1:${port}`;
  child = spawn(process.execPath, ['server.js'], {
    cwd: path.join(__dirname, '..'), stdio: ['ignore', 'pipe', 'pipe'],
    env: { ...process.env, PORT: String(port), HOST: '127.0.0.1', NODE_ENV: 'test', DEV_MODE: '1', DB_PATH: path.join(dir, 't.db'), BACKUP_HOURS: '0',
      TELEGRAM_BOT_TOKEN: '123:abc', TELEGRAM_API_BASE: `http://127.0.0.1:${tg.address().port}`, ADMIN_TG_CHAT_ID: ADMIN_CHAT,
      CARD_NUMBER: '9860 0000 1111 2222', ANTHROPIC_API_KEY: '', PAYME_MERCHANT_ID: '', PAYME_KEY: '' }
  });
  await new Promise((resolve, reject) => {
    let out = '';
    child.stdout.on('data', d => { out += d; if (out.includes('Telegram: бот @ustoz_test_bot')) resolve(); });
    child.on('exit', c => reject(new Error('server exited ' + c + out)));
  });
});
after(() => { child.kill(); tg.close(); });

async function userWithReceipt(email) {
  const lr = await fetch(BASE + '/api/auth/dev', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ email, name: 'Тест' }) });
  const sid = lr.headers.get('set-cookie').match(/sid=([^;]+)/)[1];
  const H = { 'content-type': 'application/json', cookie: 'sid=' + sid };
  const o = await (await fetch(BASE + '/api/orders', { method: 'POST', headers: H, body: JSON.stringify({ plan: 'std' }) })).json();
  const up = await fetch(`${BASE}/api/orders/${o.orderId}/receipt`, { method: 'POST', headers: { 'content-type': 'image/png', cookie: 'sid=' + sid }, body: PNG });
  assert.equal(up.status, 200);
  const me = async () => (await (await fetch(BASE + '/api/me', { headers: H })).json()).user.active;
  const mine = async () => (await (await fetch(BASE + '/api/orders/mine', { headers: H })).json()).orders[0];
  return { order: o, me, mine };
}
const press = (data, caption = 'чек') => queue.push({ callback_query: { id: 'cb' + Math.random(), data, from: { id: +ADMIN_CHAT }, message: { message_id: 42, chat: { id: +ADMIN_CHAT }, caption } } });

test('чек приходит владельцу фото с кнопками, «Подтвердить» включает подписку', async () => {
  const u = await userWithReceipt('tg-ok@test.uz');
  const photo = await waitFor(c => c.method === 'sendPhoto' && c.body.multipart.includes(`pay:ok:${u.order.orderId}`));
  assert.ok(photo.body.multipart.includes(ADMIN_CHAT));
  press(`pay:ok:${u.order.orderId}`);
  await waitFor(c => c.method === 'editMessageCaption' && c.body.caption.includes('Подтверждено'));
  assert.equal(await u.me(), true);
});

test('«Отклонить» спрашивает причину и отклоняет заказ', async () => {
  const u = await userWithReceipt('tg-no@test.uz');
  await waitFor(c => c.method === 'sendPhoto' && c.body.multipart.includes(`pay:no:${u.order.orderId}`));
  press(`pay:no:${u.order.orderId}`);
  const kb = await waitFor(c => c.method === 'editMessageReplyMarkup' && JSON.stringify(c.body).includes(`pay:no:${u.order.orderId}:nf`));
  assert.ok(kb);
  press(`pay:no:${u.order.orderId}:img`);
  await waitFor(c => c.method === 'editMessageCaption' && c.body.caption.includes('Отклонено'));
  const o = await u.mine();
  assert.equal(o.status, 'rejected'); assert.equal(o.rejectReason, 'img');
  assert.equal(await u.me(), false);
});

test('кнопки из чужого чата не работают', async () => {
  const u = await userWithReceipt('tg-foreign@test.uz');
  queue.push({ callback_query: { id: 'x', data: `pay:ok:${u.order.orderId}`, from: { id: 1 }, message: { message_id: 1, chat: { id: 1 }, caption: 'x' } } });
  await waitFor(c => c.method === 'answerCallbackQuery' && c.body.text === 'Нет доступа');
  assert.equal(await u.me(), false);
});
